var session = require('express-session');
var express = require('express');
var router = express.Router();
var connection = require("../public/database/connection");
/* GET home page. */
router.get('/', function (req, res, next) {
    res.render('index', {title: 'Express'});
});

//ADMIN ROUTES

//Add Admin Details
router.post("/add-admin", (req, res) => {
    let {uname, password, confirmpassword, newmail, fullname, phonenumber, type} = req.body;
    let emailcheckselectquery = `SELECT username,email from admin where email="${newmail}" OR username="${uname}"`;
    connection.query(emailcheckselectquery, (error, rows) => {
        console.log(rows);
        if (error) {
            return res.send("Some Technical Problems at backend");
        } else if (rows.length > 0) {
            return res.send("exists");
        } else {
            let insertQuery = `INSERT into admin(username,password,email,fullname,phoneno,type) VALUES("${uname}","${password}","${newmail}","${fullname}","${phonenumber}","${type}")`;
            connection.query(insertQuery, (error) => {
                if (error) {
                    return res.send("error");
                }
                return res.send("success");
            });
        }
    });
});


//Viewing Admin Details

router.get("/getadmindetails", (req, res) => {
    let selectquery = `select * from admin`;
    connection.query(selectquery, (error, rows) => {
        if (error) {
            return res.send("error");
        } else if (rows.length === 0) {
            return res.send("nodata");
        } else if (rows.length > 0) {
            return res.send(rows);
        }
    });
});

//Updating Admin Details
router.get("/get-data-by-username:username", (req, res) => {
    let {username} = req.params;
    let selectquery = `select username,type,status from admin where username="${username}"`;
    connection.query(selectquery, (error, rows) => {
        if (error) {
            return res.send("error");
        } else if (rows.length > 0) {
            return res.send(rows);
        }
    });
});

router.post("/update-admin-details", (req, res) => {
    let {uname, type, updatestatus} = req.body;
    let updateQuery = `update admin set type="${type}",status="${updatestatus}" where username="${uname}"`;
    connection.query(updateQuery, (error) => {
        if (error) {
            return res.send("error");
        } else {
            return res.send("success");
        }
    })
})

//Admin login
router.post("/check-details", (req, res) => {
    let {name_email, login_pass} = req.body;
    let checklogindetails = `SELECT * from admin where (email="${name_email}" OR username="${name_email}") AND password="${login_pass}"`;
    connection.query(checklogindetails, (error, rows) => {
        if (error) {
            return res.send("error");
        } else if (rows.length === 0) {
            return res.send("failure");
        } else if (rows.length > 0) {
            if (rows[0].status === 'active') {
                let adminData = {'username': rows[0].username, 'type': rows[0].type};
                console.log(adminData);
                session.adminSession = adminData;
                return res.send("success login");
            } else {
                return res.send("inactive");
            }
        }
    });
});

router.get("/check-admin-session", (req, res) => {
    if (session.adminSession === undefined) {
        return res.send("failed");
    } else {
        return res.send(session.adminSession);
    }
})

router.post("/logout", (req, res) => {
    session.adminSession = undefined;
});

router.get("/getuserbookings", (req, res) => {
    let selectquery = `SELECT * from bill`;
    connection.query(selectquery, (error, rows) => {
        if (error) {
            return res.send("error");
        } else if (rows.length === 0) {
            return res.send("nodata");
        } else if (rows.length > 0) {
            return res.send(rows);
        }
    });
})

//Admin change password
router.post("/change-admin-password", (req, res) => {
    let {oldpassword, newpassword, confirmnewpassword} = req.body;
    console.log(req.body);
    var uname = session.adminSession.username;
    // console.log(uname +"hello");
    let checkoldpassquery = `select password from admin where username="${uname}"`;
    console.log(checkoldpassquery);
    connection.query(checkoldpassquery, (error, rows) => {
        if (error) {
            console.log(error);
        } else if (oldpassword !== rows[0].password) {
            console.log(rows[0].password);
            return res.send("wrongpassword");
        } else if (oldpassword === rows[0].password) {
            let changepassquery = `UPDATE admin set password="${newpassword}" where username="${uname}";`
            connection.query(changepassquery, (error) => {
                if (error) {
                    return res.send("failure");
                } else {
                    return res.send("success");
                }
            });
        }
    });
});

//Add lab Owener
router.post("/add-lab", (req, res) => {
    let {uname, newmail, labaddress, phonenumber, password} = req.body;
    let emailcheckselectquery = `SELECT contact_email from labs where contact_email="${newmail}" `;
    connection.query(emailcheckselectquery, (error, rows) => {
        console.log(rows);
        if (error) {
            return res.send("Some Technical Problems at backend");
        } else if (rows.length > 0) {
            return res.send("exists");
        } else {
            let insertQuery = `INSERT into labs(l_id,lab_name,contact_email,lab_address,contact_no,password) VALUES(null,"${uname}","${newmail}","${labaddress}","${phonenumber}","${password}")`;
            connection.query(insertQuery, (error) => {
                if (error) {
                    return res.send("error");
                }
                return res.send("success");
            });
        }
    });
});
router.post("/getpendingowners", (req, res) => {
    let {activatestatus} = req.body;
    if (activatestatus === "pending") {
        let selectquery = `select * from labs where status="pending"`;
        connection.query(selectquery, (error, rows) => {
            if (error) {

                return res.send("error");
            } else if (rows.length === 0) {
                return res.send("nodata");
            } else if (rows.length > 0) {
                return res.send(rows);
            }
        });
    } else if (activatestatus === "activated") {
        let selectquery = `select * from labs where status="activated" OR status="blocked"`;
        connection.query(selectquery, (error, rows) => {
            if (error) {

                return res.send("error");
            } else if (rows.length === 0) {
                return res.send("nodata");
            } else if (rows.length > 0) {
                return res.send(rows);
            }
        });
    }
});

//Activate owner
router.post("/owner-actions", (req, res) => {
    let {email, accountstatus} = req.body;
    if (accountstatus === "pending") {
        let activateQuery = `update labs set status="activated" where contact_email="${email}"`;
        connection.query(activateQuery, (error) => {
            if (error) {
                console.log(error);
                return res.send("error");
            } else {
                return res.send("activated");
            }
        })
    } else if (accountstatus === "activated") {
        let activateQuery = `update labs set status="blocked" where contact_email="${email}"`;
        connection.query(activateQuery, (error) => {
            if (error) {
                console.log(error);
                return res.send("error");
            } else {
                return res.send("blocked");
            }
        })
    }
})
// Lab Login
router.post("/check-lab-details", (req, res) => {
    let {name_email, login_pass} = req.body;
    let checklogindetails = `SELECT * from labs where contact_email="${name_email}" AND password="${login_pass}"`;
    connection.query(checklogindetails, (error, rows) => {
        if (error) {
            return res.send("error");
        } else if (rows.length === 0) {
            return res.send("failure");
        } else if (rows.length > 0) {
            if (rows[0].status === 'activated') {
                console.log(rows);
                let labData = {'labname': rows[0].lab_name, 'lab_id': rows[0].l_id};

                // console.log(labData);
                session.labSession = labData;
                console.log(session.labSession);
                return res.send("success login");
            } else {
                return res.send("inactive");
            }
        }
    });
});

router.get("/check-lab-session", (req, res) => {
    if (session.labSession === undefined) {
        return res.send("failed");
    } else {
        return res.send(session.labSession);
    }
})

router.post("/lablogout", (req, res) => {
    session.labSession = undefined;
});

//Lab change password
router.post("/change-lab-password", (req, res) => {
    let {oldpassword, newpassword, confirmnewpassword} = req.body;
    console.log(req.body);
    var email = session.labSession;
    let checkoldpassquery = `select password from labs where contact_email="${email}"`;
    console.log(checkoldpassquery);
    connection.query(checkoldpassquery, (error, rows) => {
        if (error) {
            console.log(error);
        } else if (oldpassword !== rows[0].password) {
            console.log(rows[0].password);
            return res.send("wrongpassword");
        } else if (oldpassword === rows[0].password) {
            let changepassquery = `UPDATE labs set password="${newpassword}" where contact_email="${email}";`
            connection.query(changepassquery, (error) => {
                if (error) {
                    return res.send("failure");
                } else {
                    return res.send("success");
                }
            });
        }
    });
});

// Add Lab Test details

router.post("/add-labtest", (req, res) => {
    let {testname, description, category_name, price} = req.body;
    console.log(req.body);
    var labID = session.labSession.lab_id;
    let emailcheckselectquery = `SELECT test_name from labtests where test_name="${testname}" and lab="${labID}"`;
    connection.query(emailcheckselectquery, (error, rows) => {
        if (error) {
            return res.send("Some Technical Problems at backend");
        } else if (rows.length > 0) {
            return res.send("exists");
        } else {
            // let insertQuery = `INSERT into labtests(test_name,description,category,price,lab) VALUES("${testname}","${description}","${category}","${price}",${labID})`;
            let insertQuery = `insert into labtests(test_name,description,category,price,lab) values ("${testname}","${description}","${category_name}","${price}","${labID}");`;
            console.log(insertQuery);
            connection.query(insertQuery, (error) => {
                if (error) {
                    return res.send("error");
                }
                return res.send("success");
            });
        }
    });
});

//Viewing Lab Test Details

router.get("/getlabtestdetails", (req, res) => {
    let selectquery = `select * from labtests`;
    connection.query(selectquery, (error, rows) => {
        if (error) {
            return res.send("error");
        } else if (rows.length === 0) {
            return res.send("nodata");
        } else if (rows.length > 0) {
            return res.send(rows);
        }
    });
});

router.get("/get-lab-test-data-id:lt_id", (req, res) => {
    let {lt_id} = req.params;
    let selectquery = `select * from labtests where lt_id="${lt_id}"`;
    connection.query(selectquery, (error, rows) => {
        if (error) {
            return res.send("error");
        } else if (rows.length > 0) {
            return res.send(rows);
        }
    });
});

router.post("/update-labtest-details", (req, res) => {
    console.log(req.body);
    let {
        category_name
        , description, price, testname, ltid
    } = req.body;
    let updateQuery = `update labtests set test_name="${testname}",description="${description}" , category="${category_name}" , price ="${price}" where lt_id="${ltid}"`;
    connection.query(updateQuery, (error) => {
        if (error) {
            return res.send("error");
        } else {
            return res.send("success");
        }
    })
})

router.post("/deletelabtest", (req, res) => {
    let {lt_id} = req.body;
    let deletequery = `delete from labtests where lt_id="${lt_id}"`;
    console.log(deletequery);
    connection.query(deletequery, (error) => {
        if (error) {
            return res.send("error");
        } else {
            return res.send("success");
        }
    })
})

router.post("/getlabpendingtest", (req, res) => {
    let {activatestatus} = req.body;
    if (activatestatus === "pending") {
        let selectquery = `select * from labtests where status="pending"`;
        connection.query(selectquery, (error, rows) => {
            if (error) {

                return res.send("error");
            } else if (rows.length === 0) {
                return res.send("nodata");
            } else if (rows.length > 0) {
                return res.send(rows);
            }
        });
    } else if (activatestatus === "activated") {
        let selectquery = `select * from labtests where status="activated" OR status="blocked"`;
        connection.query(selectquery, (error, rows) => {
            if (error) {

                return res.send("error");
            } else if (rows.length === 0) {
                return res.send("nodata");
            } else if (rows.length > 0) {
                return res.send(rows);
            }
        });
    }
});

router.post("/lab-test-actions", (req, res) => {
    let {lt_id, accountstatus} = req.body;
    if (accountstatus === "pending") {
        let activateQuery = `update labtests set status="activated" where lt_id="${lt_id}"`;
        connection.query(activateQuery, (error) => {
            if (error) {
                console.log(error);
                return res.send("error");
            } else {
                return res.send("activated");
            }
        })
    } else if (accountstatus === "activated") {
        let activateQuery = `update labtests set status="blocked" where lt_id="${lt_id}"`;
        console.log(activateQuery);
        connection.query(activateQuery, (error) => {
            if (error) {
                console.log(error);
                return res.send("error");
            } else {
                return res.send("blocked");
            }
        })
    }
})

//(PATIENT)

//Add patient
router.post("/add-patient", (req, res) => {
    let {uname, newmail, paddress, phonenumber, password, gender} = req.body;
    let emailcheckselectquery = `SELECT contact_email from patient where contact_email="${newmail}" `;
    connection.query(emailcheckselectquery, (error, rows) => {
        console.log(rows);
        if (error) {
            return res.send("Some Technical Problems at backend");
        } else if (rows.length > 0) {
            return res.send("exists");
        } else {
            let insertQuery = `INSERT into patient(p_id,p_name,contact_email,p_address,contact_no,password,gender) VALUES(null,"${uname}","${newmail}","${paddress}","${phonenumber}","${password}","${gender}")`;
            connection.query(insertQuery, (error) => {
                if (error) {
                    return res.send("error");
                }
                return res.send("success");
            });
        }
    });
});


//Viewing patient  Details

router.get("/getpatientprofile", (req, res) => {
    let selectquery = `select * from patient where contact_email="${session.patientSession}"`;
    console.log(selectquery)
    connection.query(selectquery, (error, rows) => {
        console.log(rows)
        if (error) {
            return res.send("error");
        } else if (rows.length === 0) {
            return res.send("nodata");
        } else if (rows.length > 0) {
            return res.send(rows);
        }
    });
});

router.get("/get-patient-profile-data-id:p_id", (req, res) => {
    let {p_id} = req.params;
    console.log(p_id)
    let selectquery = `select * from patient where p_id="${p_id}"`;
    console.log(selectquery)
    connection.query(selectquery, (error, rows) => {
        if (error) {
            return res.send("error");
        } else if (rows.length > 0) {
            return res.send(rows);
        }
    });
});

//Update-patient-profile
router.post("/patient-update-profile", (req, res) => {
    console.log(req.body);
    let {
        uname, paddress, newmail, password, phonenumber, gender, pid
    } = req.body;
    let updateQuery = `update patient set p_name="${uname}", p_address="${paddress}", contact_email="${newmail}" , password="${password}" , contact_no="${phonenumber}" , gender ="${gender}" where p_id="${pid}"`;
    connection.query(updateQuery, (error) => {
        if (error) {
            return res.send("error");
        } else {
            return res.send("success");
        }
    })
})


// Patient Login
router.post("/check-patient-details", (req, res) => {
    let {name_email, login_pass} = req.body;
    let checklogindetails = `SELECT * from patient where contact_email="${name_email}" AND password="${login_pass}"`;
    connection.query(checklogindetails, (error, rows) => {
        if (error) {
            return res.send("error");
        } else if (rows.length === 0) {
            return res.send("failure");
        } else if (rows.length > 0) {
            session.patientSession = name_email;
            res.send("success login");
        } else {
            res.send("inactive");
        }
    });
});

router.get("/check-patient-session", (req, res) => {
    if (session.patientSession === undefined) {
        return res.send("failed");
    } else {
        return res.send("success");
    }
})

router.post("/patientlogout", (req, res) => {
    session.patientSession = undefined;
});

//change patient password
router.post("/change-patient-password", (req, res) => {
    let {oldpassword, newpassword, confirmnewpassword} = req.body;
    var uname = session.patientSession;
    console.log(uname);
    let checkoldpassquery = `select password from patient where contact_email="${uname}"`;
    connection.query(checkoldpassquery, (error, rows) => {
        console.log(rows);
        if (error) {
            console.log(error);
        } else if (oldpassword !== rows[0].password) {
            console.log(rows[0].password);
            return res.send("wrongpassword");
        } else if (oldpassword === rows[0].password) {
            let changepassquery = `UPDATE patient set password="${newpassword}" where contact_email="${uname}";`
            connection.query(changepassquery, (error) => {
                if (error) {
                    return res.send("failure");
                } else {
                    return res.send("success");
                }
            });
        }
    });
});

router.get("/send-patient-session", (req, res) => {
    return res.send(session.patientSession);
})

router.get("/show-test-to-users", (req, res) => {
    let selectquery = 'select * from labtests where status="activated"';
    connection.query(selectquery, (error, rows) => {
        if (error) {
            return res.send(error);
        } else {
            return res.send(rows);
        }
    })
})

router.get("/show-data-at-checkout:lt_id", (req, res) => {
    let {lt_id} = req.params;
    let selectquery = `select * from labtests where lt_id="${lt_id}"`;
    connection.query(selectquery, (error, rows) => {
        if (error) {
            return res.send(error);
        } else {
            return res.send(rows);
        }
    })
})

router.get("/show-data", (req, res) => {
    let selectquery = `select p_id from patient where contact_email="${session.patientSession}"`;
    console.log(selectquery)
    connection.query(selectquery, (error, rows) => {
        if (error) {
            return res.send(error);
        } else {
            return res.send(rows);
        }
    })
})

router.post("/cart-patient", (req, res) => {

    let {
        Price,
        Category,
        Description,
        Testname
    } = req.body;
    let insertQuery = `INSERT into cart(test_name,description,category,price,cart_id) VALUES("${Testname}","${Description}","${Category}","${Price}",null)`;
    connection.query(insertQuery, (error) => {
        if (error) {
            return res.send(error);
        }
        return res.send("success");
    })

})


router.get("/get-patient-data-checkout", (req, res) => {
    let selectquery = `select * from patient where contact_email="${session.patientSession}"`;
    connection.query(selectquery, (error, rows) => {
        if (error) {
            return res.send(error);
        } else {
            return res.send(rows);
        }

    });

})

router.post("/add-bill", (req, res) => {
    let {
        contact_email,
        contact_no,
        test_name,
        category,
        price,
        payment_method,
        lt_id,
        status
    } = req.body;
    let insertQuery = `insert into bill(lt_id,user_email,user_mobile,test_name,test_category,test_price,payment_method,status) values ("${lt_id}","${contact_email}","${contact_no}","${test_name}","${category}","${price}","${payment_method}","${status}");`;
    connection.query(insertQuery, (error) => {
        if (error) {
            return res.send(error);
        }
        return res.send("success");
    })
})

router.get("/getbookings", (req, res) => {
    let selectquery = `select * from bill where user_email="${session.patientSession}"`;
    console.log(selectquery)
    connection.query(selectquery, (error, rows) => {
        console.log(rows)
        if (error) {
            return res.send("error");
        } else if (rows.length === 0) {
            return res.send("nodata");
        } else if (rows.length > 0) {
            return res.send(rows);
        }
    });
});

router.post("/cancelbooking", (req, res) => {
    let {bill_id} = req.body;
    let deletequery = `delete from bill where bill_id="${bill_id}"`
    connection.query(deletequery, (error, rows) => {
        console.log(rows)
        if (error) {
            return res.send("error");
        }
        return res.send("success")
    });
})

router.get("/get-user-details", (req, res) => {

    let variable = `SELECT * from patient where contact_email="${session.patientSession}" `;
    connection.query(variable, (error, rows) => {
        if (error) {
            return res.send("error");
        } else if (rows.length === 0) {
            return res.send("failure");
        } else if (rows.length > 0) {
            return res.send(rows);
        }
    });
});

router.post("/contact-details", (req, res) => {
    let {uname, newmail, subject, phonenumber, message} = req.body;

    let insertQuery = `INSERT into contact (id,name,email,subject,phone,message) VALUES(null,"${uname}","${newmail}","${subject}","${phonenumber}","${message}")`;
    connection.query(insertQuery, (error) => {
        if (error) {
            return res.send("error");
        }
        return res.send("success");
    });

});

router.get("/getcontactqueries", (req, res) => {

    let variable = `SELECT * from contact where status="pending" `;
    connection.query(variable, (error, rows) => {
        console.log(rows)
        if (error) {
            return res.send("error");
        } else if (rows.length === 0) {
            return res.send("nodata");
        } else if (rows.length > 0) {
            return res.send(rows);
        }
    });
});


router.post("/statuschange", (req, res) => {
    let {id} = req.body;
    let deleteQuery = `delete from contact where id="${id}"`;
    connection.query(deleteQuery, (error) => {
        if (error) {
            return res.send("error");
        }
        return res.send("success");
    })
})
router.get("/getbookingstolabowner", (req, res) => {
    let selectquery = `SELECT * from bill where lt_id="${session.labSession.lab_id}"`;
    connection.query(selectquery, (error, rows) => {
        if (error) {
            return res.send("error");
        } else if (rows.length === 0) {
            return res.send("nodata");
        } else if (rows.length > 0) {
            return res.send(rows);
        }
    });
})


module.exports = router;