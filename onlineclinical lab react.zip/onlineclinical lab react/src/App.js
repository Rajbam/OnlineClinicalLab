import { BrowserRouter, Routes, Route } from "react-router-dom";

import AddAdmin from "./pages/admin/AddAdmin";
import AdminHome from "./pages/admin/AdminHome";
import AdminLayout from "./pages/admin/AdminLayout";
import ChangeAdminPassword from "./pages/admin/ChangeAdminPassword";
import ViewAdmin from "./pages/admin/ViewAdmin";
import AdminLogin from "./pages/admin/AdminLogin";
import EditAdmin from "./pages/admin/EditAdmin";
import ProtectedAdminRoute from "./pages/admin/ProtectedAdminRoute";
import LabSignup from "./pages/labs/LabSignup";
import LabLayout from "./pages/labs/LabLayout";
import LabHome from "./pages/labs/LabHome";
import ViewPendingOwner from "./pages/admin/ViewPendingOwners";
import SetOwnerActions from "./pages/admin/SetOwnerActions";
import LabLogin from "./pages/labs/LabLogin";
import ChangeLabPassword from "./pages/labs/ChangeLabPassword";
import ProtectedLabRoute from "./pages/labs/ProtectedLabRoute";
import { AdminSession } from "./pages/admin/AdminSession";
import AddLab from "./pages/labs/AddLab";
import ViewLabTest from "./pages/labs/ViewLabTest";
import EditLabTest from "./pages/labs/EditLabTest";
import ViewPendingLabTest from "./pages/admin/ViewPendingLabTest";
import SetLabTestActions from "./pages/admin/SetLabTestActions";
import ChangePatientPassword from "./pages/patient/ChangePatientPassword";
import PatientHome from "./pages/patient/PatientHome";
import PatientLayout from "./pages/patient/PatientLayout";
import PatientLogin from "./pages/patient/PatientLogin";
import PatientSignup from "./pages/patient/PatientSignup";
import ProtectedPatientRoute from "./pages/patient/ProtectedPatientRoute";
import UpdateProfile from "./pages/patient/UpdateProfile";
import ViewPatient from "./pages/patient/ViewPatient";
import Services from "./pages/patient/Services";
import About from "./pages/patient/About";
import Contact from "./pages/patient/Contact";
import Cart from "./pages/patient/Cart";
import CheckOut from "./pages/patient/CheckOut";
import MyBooking from "./pages/patient/MyBooking";
import ThankuPage from "./pages/patient/ThankuPage";
import ContactQueries from "./pages/admin/ContactQueries";
import ViewUserBookings from "./pages/admin/VIewUserBookings";
import ViewBooking from "./pages/labs/ViewBooking";

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          {/* ADMIN */}
          <Route path="/admin/admin-login" element={<AdminLogin />} />
          <Route
            path={"/admin"}
            element={<ProtectedAdminRoute Component={AdminLayout} />}
          >
            <Route index element={<AdminHome />} />
            <Route
              path="add-admin"
              element={<AdminSession Component={AddAdmin} />}
            />
            <Route
              path="view-admin"
              element={<AdminSession Component={ViewAdmin} />}
            />
            <Route path="edit-admin/:username" element={<EditAdmin />} />
            <Route
              path="admin-change-password"
              element={<ChangeAdminPassword />}
            />
            <Route path="view-pending-owner" element={<ViewPendingOwner />} />
            <Route path="actions-owner" element={<SetOwnerActions />} />
            <Route path="user-queries" element={<ContactQueries />} />
            <Route
              path="view-pending-lab-test"
              element={<ViewPendingLabTest />}
            />
            <Route
              path="view-lab-test-actions"
              element={<SetLabTestActions />}
            />
            <Route path="view-bookings" element={<ViewUserBookings />} />
          </Route>

          {/* LAB */}
          <Route path="/lab/lab-login" element={<LabLogin />} />
          <Route path="/lab/add-lab" element={<LabSignup />} />
          <Route
            path={"/lab"}
            element={<ProtectedLabRoute Component={LabLayout} />}
          >
            <Route index element={<ProtectedLabRoute Component={LabHome} />} />
            <Route
              path="add-labtest"
              element={<ProtectedLabRoute Component={AddLab} />}
            />
            <Route
              path="view-labtest"
              element={<ProtectedLabRoute Component={ViewLabTest} />}
            />
            <Route
              path="edit-labtest/:lt_id"
              element={<ProtectedLabRoute Component={EditLabTest} />}
            />
            <Route
              path="view-booking"
              element={<ProtectedLabRoute Component={ViewBooking} />}
            />
            {/*<Route path="view-admin" element={<ProtectedAdminRoute Component={ViewAdmin}/>}/>*/}
            <Route
              path="lab-change-password"
              element={<ProtectedLabRoute Component={ChangeLabPassword} />}
            />
          </Route>

          {/* PATIENT */}
          <Route
            path="/patient/patient-login"
            element={<ProtectedPatientRoute Component={PatientLogin} />}
          />
          <Route
            path="add-patient"
            element={<ProtectedPatientRoute Component={PatientSignup} />}
          />
          <Route path={"/patient"} element={<PatientLayout />}>
            <Route index element={<PatientHome />} />
            <Route path={"services"} element={<Services />} />
            <Route path={"about"} element={<About />} />
            <Route path={"contact"} element={<Contact />} />
            <Route
              path="patient-change-password"
              element={
                <ProtectedPatientRoute Component={ChangePatientPassword} />
              }
            />
            <Route
              path="patient-update-profile/:p_id"
              element={<ProtectedPatientRoute Component={UpdateProfile} />}
            />
            <Route
              path="view-patient-test"
              element={<ProtectedPatientRoute Component={ViewPatient} />}
            />
            <Route
              path="checkout"
              element={<ProtectedPatientRoute Component={CheckOut} />}
            />
            <Route
              path="my-booking"
              element={<ProtectedPatientRoute Component={MyBooking} />}
            />
            <Route
              path="cart/:lt_id"
              element={<ProtectedPatientRoute Component={Cart} />}
            />
            <Route
              path="thank-you"
              element={<ProtectedPatientRoute Component={ThankuPage} />}
            />
          </Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
