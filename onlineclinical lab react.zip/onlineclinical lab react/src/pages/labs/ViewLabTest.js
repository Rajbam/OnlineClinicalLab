import {useNavigate} from "react-router-dom";
import axios from "axios";
import {useEffect, useState} from "react";
import ReactLoading from 'react-loading';
import {FaTrashAlt, FaUserEdit} from "react-icons/fa";
import Banner from "../../component/banner";
import Swal from "sweetalert2";

export default function ViewLabTest() {
    let navigate = useNavigate();
    let [data, setData] = useState([]);
    let [stat, setStat] = useState(false);

    function getData() {
        setStat(false);
        axios.get("http://localhost:4000/getlabtestdetails").then((response) => {
            setTimeout(() => {
                if (response.data !== "nodata") {
                    setData(response.data);
                    setStat(true);
                    console.log(response.data);
                } else if (response.data === "nodata") {
                    setData([]);
                    setStat(true);
                }
            }, 3000)
        }).catch((error) => {
            console.log(error);
        })
    }

    useEffect(() => {
        getData();
    }, []);

    function deletetest(lt_id) {
        Swal.fire({
            title: 'Are you sure to delete labtest?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                axios.post("http://localhost:4000/deletelabtest", {'lt_id': lt_id}).then((response) => {
                    console.log(response.data);
                    if (response.data === "success") {
                        Swal.fire(
                            'Deleted',
                            'Your Lab test has been deleted',
                            'success'
                        )
                        getData();
                    } else {
                        Swal.fire(
                            'Error',
                            'Lab test cannot be deleted. Please try again after sometime!',
                            'error'
                        )
                    }
                })
            }
        })
    }


    return (
        <>
            <Banner name={" View Lab Test"} Previous={"Lab Home"}/>
            {
                stat ?
                    data.length === 0 ?
                        <div className={"custom-flex container bg-inactive"}><h1
                            className={"custom-flex pt-5 font height-view"}>No Data
                            Found!!</h1>
                        </div> :
                        <section className="ftco-section">
                            <div className="container">
                                <div className="row justify-content-center">
                                    <div className="col-md-6 text-center mb-5">
                                        <h2 className="style-font">LAB TEST DETAILS</h2>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-12">
                                        <div className="table-wrap" style={{overflow: "auto"}}>
                                            <table className="table table-responsive-xl">
                                                <thead>
                                                <tr>
                                                    <th>Lab Test ID</th>
                                                    <th>Testname</th>
                                                    <th>Description</th>
                                                    <th>Category</th>
                                                    <th>Price</th>
                                                    <th>Status</th>
                                                    <th>Lab No</th>
                                                    <th colSpan={"2"} className={"text-center"}>Actions</th>



                                                </tr>
                                                </thead>
                                                <tbody>
                                                {
                                                    data.map((value, index) => {
                                                        let {
                                                            lt_id,
                                                            test_name,
                                                            description,
                                                            category,
                                                            price,
                                                            status,
                                                            lab
                                                        } = value;
                                                        return (
                                                            <tr key={index}>
                                                                <td>{lt_id}</td>
                                                                <td>{test_name}</td>
                                                                <td>{description}</td>
                                                                <td>{category}</td>
                                                                <td>{price}</td>

                                                                {
                                                                    status === "active" ? <td className={"status"}><span
                                                                        className="active">{status}</span>
                                                                    </td> :status === "inactive" ? <td className={"status"}><span
                                                                        className="inactive">{status}</span>
                                                                    </td>:<td className={"status"}><span
                                                                        className="pending">{status}</span>
                                                                    </td>
                                                                }
                                                                <td>{lab}</td>
                                                                <td>
                                                                    <button onClick={() => {
                                                                        navigate(`/lab/edit-labtest/${lt_id}`)
                                                                    }} type={"button"} className={"btn btn-warning"}>
                                                                        <FaUserEdit/>
                                                                    </button>
                                                                </td>
                                                                <td>
                                                                    <button type={"button"}
                                                                            onClick={() => deletetest(lt_id)}
                                                                            className={"btn btn-danger"}>
                                                                        <FaTrashAlt/>
                                                                    </button>
                                                                </td>

                                                            </tr>
                                                        )
                                                    })
                                                }
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section> :
                    <>
                        <div className={"custom-flex"}><h1 className={"font"}>Fetching Data</h1><ReactLoading
                            className={"d-flex justify-content-center"}
                            type={"balls"} color={"darkred"} height={800} width={90}/>
                        </div>
                    </>
            }
        </>
    )
}