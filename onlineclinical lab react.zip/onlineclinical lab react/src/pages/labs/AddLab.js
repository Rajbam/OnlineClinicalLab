import Banner from "../../component/banner";

import {useForm} from "react-hook-form";
import {ErrorMessage} from "@hookform/error-message";
import axios from "axios";
import Swal from "sweetalert2";

export default function AddLab() {
    let {register, handleSubmit, formState: {errors}, getValues, reset} = useForm();

    function onSubmit(data) {
        console.log(data);
        axios.post("http://localhost:4000/add-labtest", data).then((response) => {
            console.log(response.data)
            if (response.data === "success") {
                reset();
                Swal.fire(
                    'Details Added!',

                    'Lab test details has been added successfully',
                    'success'
                )

            } else if (response.data === "exists") {
                Swal.fire(
                    'Error',
                    'Lab Test or Category already exists!!',
                    'error'
                )
            } else {
                Swal.fire(
                    'Error',
                    'Details cannot be added. Please try again after sometime!',
                    'error'
                )
            }
        }).catch((error) => {
            console.log(error);
        })
    }

    return (
        <>
            <Banner name={" Lab Test"} Previous={"Lab Home"}/>
            <section className="contact py-5 bg-img">
                <div>
                    <div className="text-center mb-3">
                        <h3 className={"style-font"}>ADD LAB TESTS</h3>
                    </div>
                    <div className="form-inner-cont mx-auto container col-md-8 offset-md-2">
                        <form onSubmit={handleSubmit(onSubmit)}>
                            <div className="row align-form-map">
                                <div className="col-sm-6 form-input">
                                    <input {...register('testname', {
                                        required: "You must specify a testname",
                                        minLength: {
                                            value: 8,
                                            message: "You must enter atleast 8 characters"
                                        },
                                        maxLength: {
                                            value: 19,
                                            message: "Please enter less than 20 characters"
                                        }

                                    })} type="text"
                                           className="form-control" placeholder="Enter Lab test name"/>
                                </div>
                                <ErrorMessage name="testname" errors={errors}
                                              render={({message}) => <p className="text-danger">{message}</p>}/>



                                <div className="col-sm-6 form-input">
                                    <input {...register('description', {required: "You must specify description"})} type="text"
                                           className="form-control" placeholder="Enter description"/>
                                </div>
                                <ErrorMessage name="description" errors={errors}
                                              render={({message}) => <p className="text-danger">{message}</p>}/>

                                <div className="col-sm-6 form-input">
                                    <select
                                        className={"form-control"} {...register('category_name', {required: "You must specify category name"})}
                                        name="type">
                                        <option className={"form-control"} value="select-type"
                                                disabled>-Select type-
                                        </option>
                                        <option className={"form-control"} value="Human">Human</option>
                                        <option className={"form-control"} value="Animal">Animal</option>

                                    </select>
                                </div>
                                <ErrorMessage name="category" errors={errors}
                                              render={({message}) => <p className="text-danger">{message}</p>}/>
                                <div className="col-sm-6 form-input">
                                    <input {...register('price', {required: "You must specify a  price"})} type="number"
                                           className="form-control" placeholder="Enter Price"/>
                                </div>
                                <ErrorMessage name="price" errors={errors}
                                              render={({message}) => <p className="text-danger">{message}</p>}/>


                            </div>
                            <div className={"d-flex justify-content-center"}>
                                <button className="btn me-3 mt-3 btn-primary sent-butnn">Add Details</button>
                                <button className="btn ht-btn mt-3 btn-danger btn-block danger-butnn"
                                        onClick={() => reset()}>Reset Details
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </>
    )
}
