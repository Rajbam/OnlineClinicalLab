import Banner from "../../component/banner";
import {NavLink} from "react-router-dom";

export  default function  LabHome(){
     return(
         <>
             <Banner name={"Lab Home"} Previous={""}/>

             <h1 align="center">Lab  Dashboard</h1>

             <div className="container">
                 <div className="row">
                     <div className="col-sm-4">
                         <div className="card mb-3" style={{width: '100%', height: '200px',backgroundColor: '#d2525e'}}>
                             <div className="card-body">
                                 <h3 className="text-center">Add lab Test</h3>
                             </div>
                             <NavLink to={"/lab/add-labtest"} className="card-footer text-center text-decoration-none" style={{backgroundColor: 'black'}}><p>View Pending Lab Owners <i className="fa fa-arrow-right me-3"></i></p></NavLink>

                         </div>
                     </div>
                     <div className="col-sm-4">
                         <div className="card mb-3" style={{width: '100%', height: '200px',backgroundColor: 'violet'}}>
                             <div className="card-body">
                                 <h3 className="text-center">View Lab Test</h3>
                             </div>
                             <NavLink to={"/lab/view-labtest"} className="card-footer text-center text-decoration-none" style={{backgroundColor: 'black'}}><p>Set Lab Owner Actions  <i className="fa fa-arrow-right me-3"></i></p> </NavLink>

                         </div>
                     </div>
                     <div className="col-sm-4">
                         <div className="card mb-3" style={{width: '100%', height: '200px',backgroundColor: 'springgreen'}}>
                             <div className="card-body">
                                 <h3 className="text-center">Change Password</h3>
                             </div>
                             <NavLink to={"/lab/lab-change-password"} className="card-footer text-center text-decoration-none" style={{backgroundColor: 'black'}}><p>View Pending Lab Test <i className="fa fa-arrow-right me-3"></i></p> </NavLink>

                         </div>
                     </div>
                     <div className="col-sm-4">
                         <div className="card mb-3" style={{width: '100%', height: '200px',backgroundColor: '#dee2e6'}}>
                             <div className="card-body">
                                 <h3 className="text-center">View Booking</h3>

                             </div>
                             <NavLink to={"/lab/view-booking"} className="card-footer text-center text-decoration-none" style={{backgroundColor: 'black'}}><p>Set Lab Test Actions<i className="fa fa-arrow-right me-3"></i> </p></NavLink>

                         </div>
                     </div>

                 </div>
             </div>

         </>
     )
}