import {useEffect} from "react";
import {useNavigate} from "react-router-dom";
import axios from "axios";

export default function ProtectedLabRoute({Component}) {
    let navigate = useNavigate();
    useEffect(() => {
        axios.get("http://localhost:4000/check-lab-session").then((response) => {
            if (response.data === "failed") {
                navigate("/lab/lab-login");
            }
        }).catch((error) => {
            console.log(error);
        })
    }, []);
    return (
        <>
            <Component/>
        </>
    )
}