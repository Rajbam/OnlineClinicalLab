import {useNavigate, useParams} from "react-router-dom";
import Swal from "sweetalert2";
import {ErrorMessage} from "@hookform/error-message";
import axios from "axios";
import {useForm} from "react-hook-form";
import {useEffect, useState} from "react";
import Banner from "../../component/banner";

export default function EditLabTest() {
    let navigate = useNavigate();
    let {lt_id} = useParams();
    let [ltid, setltid] = useState(null);
    let {register, handleSubmit, formState: {errors}, setValue, reset} = useForm();
    useEffect(() => {
        reset();
        axios.get(`http://localhost:4000/get-lab-test-data-id${lt_id}`).then((response) => {
            console.log(response.data);
            if (response.data === "error") {
                Swal.fire('Error!!', 'Some error occured in fetching details!!', 'error');
            } else {
                response.data.map((value, index) => {
                    let {
                        category,
                        description,
                        lab,
                        lt_id,
                        price,
                        status,
                        test_name


                    } = value;
                    setltid(lt_id);
                    setValue("testname", test_name);
                    setValue("description", description);
                    setValue("category_name", category);
                    setValue("price", price);

                })
            }
        }).catch((error) => {
            console.log(error);
        })
    }, []);

    function onSubmit(data) {
        let {category_name, description, price, testname} = data;
        let sendData = {
            category_name,
            description,
            price,
            testname,
            ltid: ltid
        }
        axios.post("http://localhost:4000/update-labtest-details", sendData).then((response) => {
            if (response.data === "error") {
                Swal.fire('Error', 'Some technical error occured!!', 'error');
                navigate("/lab/view-labtest");
            } else if (response.data === "success") {
                Swal.fire('Updated', 'Details have been updated successfully!!', 'success');
                navigate("/lab/view-labtest");
            } else {
                Swal.fire('Error', 'Some error occured!!', 'error');
                navigate("/lab/view-labtest");
            }
        }).catch((error) => {
            console.log(error);
        });
    }

    return (
        <>
            <Banner name={"Edit Lab Test"} Previous={"Lab Home"}/>
            <section className="contact py-5 bg-img">
                <div>
                    <div className="text-center mb-3">
                        <h3 className={"style-font"}>EDIT LAB TESTS</h3>
                    </div>
                    <div className="form-inner-cont mx-auto container col-md-8 offset-md-2">
                        <form onSubmit={handleSubmit(onSubmit)}>
                            <div className="row align-form-map">
                                <div className="col-sm-6 form-input">
                                    <input {...register('testname', {
                                        required: "You must specify a testname",
                                        minLength: {
                                            value: 8,
                                            message: "You must enter atleast 8 characters"
                                        },
                                        maxLength: {
                                            value: 19,
                                            message: "Please enter less than 20 characters"
                                        }

                                    })} type="text"
                                           className="form-control" placeholder="Enter Lab test name"/>
                                </div>
                                <ErrorMessage name="testname" errors={errors}
                                              render={({message}) => <p className="text-danger">{message}</p>}/>


                                <div className="col-sm-6 form-input">
                                    <input {...register('description', {required: "You must specify description"})}
                                           type="text"
                                           className="form-control" placeholder="Enter description"/>
                                </div>
                                <ErrorMessage name="description" errors={errors}
                                              render={({message}) => <p className="text-danger">{message}</p>}/>

                                <div className="col-sm-6 form-input">
                                    <select
                                        className={"form-control"} {...register('category_name', {required: "You must specify category name"})}
                                        name="type">
                                        <option className={"form-control"} value="select-type"
                                                disabled>-Select type-
                                        </option>
                                        <option className={"form-control"} value="Human">Human</option>
                                        <option className={"form-control"} value="Animal">Animal</option>

                                    </select>
                                </div>
                                <ErrorMessage name="category" errors={errors}
                                              render={({message}) => <p className="text-danger">{message}</p>}/>
                                <div className="col-sm-6 form-input">
                                    <input {...register('price', {required: "You must specify a  price"})} type="number"
                                           className="form-control" placeholder="Enter Price"/>
                                </div>
                                <ErrorMessage name="price" errors={errors}
                                              render={({message}) => <p className="text-danger">{message}</p>}/>


                            </div>
                            <div className={"d-flex justify-content-center"}>

                                <button className={"btn sent-butnn btn-primary mr-3"}>Edit Details</button>

                            </div>
                        </form>
                    </div>
                </div>
            </section>
        </>
    )
}