import banner from "../../component/banner";
import Banner from "../../component/banner";

import {useForm} from "react-hook-form";
import {ErrorMessage} from "@hookform/error-message";
import axios from "axios";
import Swal from "sweetalert2";

export default function LabSignup() {
    let {register, handleSubmit, formState: {errors}, getValues, reset} = useForm();

    function onSubmit(data) {
        console.log(data);
        axios.post("http://localhost:4000/add-lab", data).then((response) => {
            if (response.data === "success") {
                reset();
                Swal.fire(
                    'Details Added!',
                    'Lab Owner has been sent successfully',
                    'success'
                )

            } else if (response.data === "exists") {
                Swal.fire(
                    'Error',
                    'name or email already exists!!',
                    'error'
                )
            } else {
                Swal.fire(
                    'Error',
                    'Details cannot be added. Please try again after sometime!',
                    'error'
                )
            }
        }).catch((error) => {
            console.log(error);
        })
    }

    return (
        <>
            <div className={"d-flex align-content-center"} style={{backgroundImage:`url(${require('../../images/about.jpg')})`,backgroundRepeat:"no-repeat",backgroundSize:"cover", height:'100vh',width:'100%'  }}>
                <div className="d-flex justify-content-center col-md-8 offset-md-2 " >
                    <div className="">

                        <div className="form-container " style={{marginTop:"12%"}}>
                            <div className="left-content" style={{height:"78vh"}}>
                                <h3 className="title">Lab Owner Panel</h3>
                                <h4 className="sub-title">Fusion Clinical Lab</h4>
                            </div>
                            <div className="right-content" style={{height:"10vh"}}>
                                <h3 className="form-title"> lab SignUp</h3>
                                <form className="form-horizontal" onSubmit={handleSubmit(onSubmit)}>
                                    <div className="form-group">
                                        <label>Enter labname</label>
                                        <input {...register('uname', {
                                            required: "You must specify a username",
                                            minLength: {
                                                value: 8,
                                                message: "You must enter atleast 8 characters"
                                            },
                                            maxLength: {
                                                value: 19,
                                                message: "Please enter less than 20 characters"
                                            },

                                        })} type="text"
                                               className="form-control" placeholder=""/>

                                    </div>
                                    <ErrorMessage name="uname" errors={errors}
                                                  render={({message}) => <p className="text-danger">{message}</p>}/>
                                    <div className="form-group">
                                        <label>Enter Email</label>
                                        <input {...register('newmail', {
                                            required: "You must specify email",
                                            pattern: {
                                                value: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                                                message: "Enter valid email"
                                            }
                                        })} type="text"
                                               className="form-control" placeholder=""/>
                                    </div>
                                    <ErrorMessage name="newmail" errors={errors}
                                                  render={({message}) => <p className="text-danger">{message}</p>}/>
                                    <div className="form-group">
                                        <label>Enter Lab address</label>
                                    <input {...register('labaddress', {required: "You must specify name"})} type="text"
                                           className="form-control" placeholder=""/>
                                    </div>
                                    <ErrorMessage name="labaddress" errors={errors}
                                                  render={({message}) => <p className="text-danger">{message}</p>}/>
                                    <div className="form-group">
                                        <label>Enter Password</label>
                                        <input {...register('password', {
                                            required: "You must specify a password",
                                            minLength: {
                                                value: 8,
                                                message: "Password must have at least 8 characters"
                                            },
                                            maxLength: {
                                                value: 12,
                                                message: "Please enter less than 13 characters"
                                            }
                                        })} type="password"
                                               className="form-control" placeholder=""/>
                                    </div>
                                    <ErrorMessage name="password" errors={errors}
                                                  render={({message}) => <p className="text-danger">{message}</p>}/>
                                    <div className="form-group">
                                        <label>Enter Phonenumber</label>
                                        <input {...register('phonenumber', {
                                            required: "You must specify mobile number",
                                            pattern: {
                                                value: /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/,
                                                message: "Enter valid mobile number"
                                            }
                                        })}
                                               type="text"
                                               className="form-control" placeholder=""/>
                                    </div>
                                    <ErrorMessage name="phonenumber" errors={errors}
                                                  render={({message}) => <p className="text-danger">{message}</p>}/>
                                    <ErrorMessage name="type" errors={errors}
                                                  render={({message}) => <p className="text-danger">{message}</p>}/>

                                    <button className="btn signin">Signup</button>
                                </form>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </>
    )
}
