import {NavLink} from "react-router-dom"
import {useEffect, useState} from "react";
import axios from "axios";
import {HashLink as Link} from "react-router-hash-link";

export default function PatientHome() {

    let [userdata, setUserData] = useState([]);
    useEffect(() => {
        axios.get("http://localhost:4000/show-test-to-users").then((response) => {
            setUserData(response.data);
        }).catch((error) => {
            console.log(error);
        })
    }, []);
    return (
        <>


            <section className="w3l-main-slider" id="home">
                <div className="banner-content">
                    <div id="demo-1">
                        <div className="demo-inner-content">
                            <div className="container">
                                <div className="banner-info">
                                    <p id={"home"} className="mb-1">Only one kind of Treatement!</p>
                                    <h3>Your New Smile</h3>
                                    <NavLink className="btn btn-primary btn-style btn-style-2 mt-sm-5 mt-4"
                                             to="/patient/patient-login">Book
                                        Now</NavLink>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="w3l-servicesblock py-5">
                <div className="container py-md-5 py-4">
                    <div className="row pb-xl-5 align-items-center">
                        <div className="col-lg-6 position-relative home-block-3-left pb-lg-0 pb-5">
                            <div className="position-relative">
                                <img src="/images/home1.jpg" alt="" className="img-fluid radius-image"/>
                            </div>
                            <div className="imginfo__box">
                                <h6 className="imginfo__title">Get a Appointment Today!</h6>
                                <p>Nemo enim ipsam oluptatem quia oluptas<br/> sit aspernatur aut odit aut fugit.</p>
                                <NavLink to="tel:http://+91 8077658635"><i
                                    className="fas fa-phone-alt"></i> +91 8770658635</NavLink>
                            </div>
                        </div>
                        <div className="col-xl-5 col-lg-6 offset-xl-1 mt-lg-0 mt-5 pt-lg-0 pt-5">
                            <h3 className="title-style mb-md-5 mb-4">A Warm <span>Welcome</span> and a
                                Beautiful <span>Smile</span>
                            </h3>
                            <p className="sub-para">"Our clients are our priority, we offer quality dental services
                                with a team of
                                specialists. More details about our services below".</p>
                            <p className="mt-4 pt-sm-2">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo,
                                ultrices in ligula. Semper at tempufddfel. Lorem ipsum dolor sit amet consectetur
                                adipisicing
                                elit.</p>
                            <p className="mt-4 pt-sm-2">Sellen tesque libero ut justo,
                                ultrices in ligula. Semper at tempufddfel. Lorem ipsum dolor sit amet consectetur
                                adipisicing
                                elit.</p>
                        </div>
                    </div>
                </div>
            </section>

            <section className="about-section text-center pt-lg-5 pb-5">
                <div className="container pt-lg-5 pb-lg-5 pb-4">
                    <h3 className="title-style text-center mb-5">Healthy Smiles <span>Everyday!</span></h3>
                    <div className="row justify-content-center">
                        <div className="col-lg-4 col-md-6">
                            <div className="about-single p-3">
                                <div className="about-icon mb-4">
                                    <i className="fas fa-tooth"></i>
                                </div>
                                <div className="about-content">
                                    <h5 className="mb-3"><NavLink to="/patient/about">General Dentistry</NavLink></h5>
                                    <p>Sed ut perspiciatis unde omnis iste natus error sit accusa ntium dolor emque
                                        laudan.</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 mt-md-0 mt-3">
                            <div className="about-single p-3">
                                <div className="about-icon mb-4">
                                    <i className="fas fa-wheelchair"></i>
                                </div>
                                <div className="about-content">
                                    <h5 className="mb-3"><NavLink to="/">Urgent NeuroSurgery</NavLink></h5>
                                    <p>Sed ut perspiciatis unde omnis iste natus error sit accusa ntium dolor emque
                                        laudan.</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 mt-lg-0 mt-3">
                            <div className="about-single p-3">
                                <div className="about-icon mb-4">
                                    <i className="fas fa-user-md"></i>
                                </div>
                                <div className="about-content">
                                    <h5 className="mb-3"><NavLink to="/patient/about">Dental Implants</NavLink></h5>
                                    <p>Sed ut perspiciatis unde omnis iste natus error sit accusa ntium dolor emque
                                        laudan.</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 mt-4">
                            <div className="about-single p-3">
                                <div className="about-icon mb-4">
                                    <i className="fas fa-eye-dropper"></i>
                                </div>
                                <div className="about-content">
                                    <h5 className="mb-3"><NavLink to="/">Blood Test</NavLink></h5>
                                    <p>Sed ut perspiciatis unde omnis iste natus error sit accusa ntium dolor emque
                                        laudan.</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 mt-4">
                            <div className="about-single p-3">
                                <div className="about-icon mb-4">
                                    <i className="fas fa-hand-holding-heart"></i>
                                </div>
                                <div className="about-content">
                                    <h5 className="mb-3"><NavLink to="/">Cardio Test</NavLink></h5>
                                    <p>Sed ut perspiciatis unde omnis iste natus error sit accusa ntium dolor emque
                                        laudan.</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 mt-4">
                            <div className="about-single p-3">
                                <div className="about-icon mb-4">
                                    <i className="fas fa-male"></i>
                                </div>
                                <div className="about-content">
                                    <h5 className="mb-3"><NavLink to="/">Gastrointestinal Test</NavLink></h5>
                                    <p>Sed ut perspiciatis unde omnis iste natus error sit accusa ntium dolor emque
                                        laudan.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <NavLink to="/patient/services" className="btn btn-style btn-style-2 btn-primary mt-sm-5 mt-4">Learn
                        More</NavLink>
                </div>
            </section>

            <div className="service-section py-5">
                <div className="container py-md-5 py-4">
                    <h3 className="title-style text-center mb-sm-5 mb-4">Our <span>Services</span></h3>
                    <div className="row">
                        {
                            userdata.map((value, index) => {
                                let {
                                    category,
                                    description,
                                    test_name,
                                    price,
                                    lt_id

                                } = value;
                                return (
                                    <>

                                        <div className="col-sm-4">
                                            <div className="card">
                                                <div className="card-body">
                                                    <form>
                                                        <h5 className="card-title">Category:{category}</h5>
                                                        <p className="card-text">Test Name: {test_name}</p>
                                                        <p className="card-text">Description: {description}</p>
                                                        <p className="card-text"
                                                           style={{fontWeight: "bold"}}>Price: &#8377; {price}</p>
                                                        <NavLink to={`cart/${lt_id}`} className="btn btn-primary">Add To
                                                            Cart</NavLink>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </>
                                )
                            })
                        }
                    </div>

                </div>
            </div>

            <section className="w3l-index5 py-5">
                <div className="container py-md-5 py-4">
                    <h3 className="title-style text-center mb-5">Our Best <span>Services</span></h3>
                    <div className="inner-sec-w3layouts mt-md-5 mt-4">
                        <div className="owl-three owl-carousel owl-theme">
                            <div className="item">
                                <div className="content-left-sec">
                                    <NavLink className="blog-link d-block zoom-image" to="/"><img
                                        src="/images/s1.jpg"
                                        className="img-fluid scale-image" alt=""/></NavLink>
                                    <div className="blog-info">
                                        <NavLink to="#url">
                                            <h4 className="mb-0">Sedation Dentistry</h4>
                                        </NavLink>
                                        <p>Donec luctus rhoncus dignissim. Integer blandit mattis arcu, id orci.</p>
                                        <NavLink to="/patient/services" className="btn btn-style-primary">Learn More<i
                                            className="fas fa-arrow-right"></i></NavLink>
                                    </div>
                                </div>
                            </div>
                            <div className="item">
                                <div className="content-left-sec">
                                    <NavLink className="blog-link d-block zoom-image" to=""><img
                                        src="/images/s2.jpg"
                                        className="img-fluid scale-image" alt=""/></NavLink>
                                    <div className="blog-info">
                                        <NavLink to="#url">
                                            <h4 className="mb-0">Child’s Dental Care</h4>
                                        </NavLink>
                                        <p>Donec luctus rhoncus dignissim. Integer blandit mattis arcu, id orci.</p>
                                        <NavLink to="/patient/services" className="btn btn-style-primary">Learn More<i
                                            className="fas fa-arrow-right"></i></NavLink>
                                    </div>
                                </div>
                            </div>
                            <div className="item">
                                <div className="content-left-sec">
                                    <NavLink className="blog-link d-block zoom-image" to="/"><img
                                        src="/images/s3.jpg"
                                        className="img-fluid scale-image" alt=""/></NavLink>
                                    <div className="blog-info">
                                        <NavLink to="#url">
                                            <h4 className="mb-0">Family Dental Care</h4>
                                        </NavLink>
                                        <p>Donec luctus rhoncus dignissim. Integer blandit mattis arcu, id orci.</p>
                                        <NavLink to="/patient/services" className="btn btn-style-primary">Learn More<i
                                            className="fas fa-arrow-right"></i></NavLink>
                                    </div>
                                </div>
                            </div>
                            <div className="item">
                                <div className="content-left-sec">
                                    <NavLink className="blog-link d-block zoom-image" to="/"><img
                                        src="/images/s4.jpg"
                                        className="img-fluid scale-image" alt=""/></NavLink>
                                    <div className="blog-info">
                                        <NavLink to="#url">
                                            <h4 className="mb-0">Cosmetic Dentistry</h4>
                                        </NavLink>
                                        <p>Donec luctus rhoncus dignissim. Integer blandit mattis arcu, id orci.</p>
                                        <NavLink to="/" className="btn btn-style-primary">Learn More<i
                                            className="fas fa-arrow-right"></i></NavLink>
                                    </div>
                                </div>
                            </div>
                            <div className="item">
                                <div className="content-left-sec">
                                    <NavLink className="blog-link d-block zoom-image" to="/"><img
                                        src="/images/s5.jpg"
                                        className="img-fluid scale-image" alt=""/></NavLink>
                                    <div className="blog-info">
                                        <NavLink to="/">
                                            <h4 className="mb-0">Cleaning with Air Flow</h4>
                                        </NavLink>
                                        <p>Donec luctus rhoncus dignissim. Integer blandit mattis arcu, id orci.</p>
                                        <NavLink to="/patient/services" className="btn btn-style-primary">Learn More<i
                                            className="fas fa-arrow-right"></i></NavLink>
                                    </div>
                                </div>
                            </div>
                            <div className="item">
                                <div className="content-left-sec">
                                    <NavLink className="blog-link d-block zoom-image" to="/"><img
                                        src="/images/s7.jpg"
                                        className="img-fluid scale-image" alt=""/></NavLink>
                                    <div className="blog-info">
                                        <NavLink to="/">
                                            <h4 className="mb-0">Complete Whitening</h4>
                                        </NavLink>
                                        <p>Donec luctus rhoncus dignissim. Integer blandit mattis arcu, id orci.</p>
                                        <NavLink to="/patient/services" className="btn btn-style-primary">Learn More<i
                                            className="fas fa-arrow-right"></i></NavLink>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="w3-bottom-stats py-5">
                <div className="container py-md-5 py-4">
                    <div className="row py-4">
                        <div className="col-md-7 pe-lg-5">
                            <h5 className="text-new mb-4">We are proud to have the opportunity to give you the smile of
                                your dreams.
                            </h5>
                            <p className="mb-3">Nibh eu consequat magna ipsum ac ex. Nulla iaculis
                                tincidunt elit, tortor luctus sit amet.
                            </p>
                            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque
                                laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi
                                architecto beatae vitae dicta sunt explicabo.</p>
                            <NavLink to="/patient/about" className="btn btn-style btn-style-2 mt-lg-5 mt-4">Learn
                                More</NavLink>
                        </div>
                        <div className="col-md-5 text-md-center mt-md-0 mt-5">
                            <div className="counter">
                                <div className="timer count-title count-number" data-to="6370" data-speed="1500">6370
                                </div>
                                <p className="count-text mt-sm-2">Happy Smiles</p>
                            </div>
                            <div className="counter mt-sm-5 mt-4">
                                <div className="timer count-title count-number" data-to="36" data-speed="1500">36</div>
                                <p className="count-text mt-sm-2">Years of experience</p>
                            </div>
                            <div className="counter mt-sm-5 mt-4">
                                <div className="timer count-title count-number" data-to="7600" data-speed="1500">7600
                                </div>
                                <p className="count-text mt-sm-2">Patients a year</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="w3l-team py-5">
                <div className="container py-md-5 py-4">
                    <h3 className="title-style text-center mb-5">Meet Our <span>Doctors</span></h3>
                    <div className="row text-center">
                        <div className="col-lg-3 col-sm-6">
                            <div className="team-block-single">
                                <div className="team-grids">
                                    <NavLink to="#team-single">
                                        <img src="/images/team1.jpg" className="img-fluid" alt=""/>
                                        <div className="team-info">
                                            <div className="social-icons-section">
                                                <NavLink className="fac" to="#facebook">
                                                    <i className="fab fa-facebook-f"></i>
                                                </NavLink>
                                                <NavLink className="twitter mx-2" to="#twitter">
                                                    <i className="fab fa-twitter"></i>
                                                </NavLink>
                                                <NavLink className="google" to="#google-plus">
                                                    <i className="fab fa-google-plus-g"></i>
                                                </NavLink>
                                            </div>
                                        </div>
                                    </NavLink>
                                </div>
                                <div className="team-bottom-block p-4">
                                    <h5 className="member mb-1"><NavLink to="#team">Olive Yew</NavLink></h5>
                                    <small>Neuro Surgeon</small>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-sm-6 mt-sm-0 mt-4">
                            <div className="team-block-single">
                                <div className="team-grids">
                                    <NavLink to="#team-single">
                                        <img src="/images/team2.jpg" className="img-fluid" alt=""/>
                                        <div className="team-info">
                                            <div className="social-icons-section">
                                                <NavLink className="fac" to="#facebook">
                                                    <i className="fab fa-facebook-f"></i>
                                                </NavLink>
                                                <NavLink className="twitter mx-2" to="#twitter">
                                                    <i className="fab fa-twitter"></i>
                                                </NavLink>
                                                <NavLink className="google" to="#google-plus">
                                                    <i className="fab fa-google-plus-g"></i>
                                                </NavLink>
                                            </div>
                                        </div>
                                    </NavLink>
                                </div>
                                <div className="team-bottom-block p-4">
                                    <h5 className="member mb-1 active"><NavLink to="#team">Aida Joe</NavLink></h5>
                                    <small>Orthodontist</small>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-sm-6 mt-lg-0 mt-4">
                            <div className="team-block-single">
                                <div className="team-grids">
                                    <NavLink to="#team-single">
                                        <img src="/images/team3.jpg" className="img-fluid" alt=""/>
                                        <div className="team-info">
                                            <div className="social-icons-section">
                                                <NavLink className="fac" to="#facebook">
                                                    <i className="fab fa-facebook-f"></i>
                                                </NavLink>
                                                <NavLink className="twitter mx-2" to="#twitter">
                                                    <i className="fab fa-twitter"></i>
                                                </NavLink>
                                                <NavLink className="google" to="#google-plus">
                                                    <i className="fab fa-google-plus-g"></i>
                                                </NavLink>
                                            </div>
                                        </div>
                                    </NavLink>
                                </div>
                                <div className="team-bottom-block p-4">
                                    <h5 className="member mb-1"><NavLink to="#team">Teri Dac</NavLink></h5>
                                    <small>Cardiologist</small>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-sm-6 mt-lg-0 mt-4">
                            <div className="team-block-single">
                                <div className="team-grids">
                                    <NavLink to="#team-single">
                                        <img src="/images/team4.jpg" className="img-fluid" alt=""/>
                                        <div className="team-info">
                                            <div className="social-icons-section">
                                                <NavLink className="fac" to="#facebook">
                                                    <i className="fab fa-facebook-f"></i>
                                                </NavLink>
                                                <NavLink className="twitter mx-2" to="#twitter">
                                                    <i className="fab fa-twitter"></i>
                                                </NavLink>
                                                <NavLink className="google" to="#google-plus">
                                                    <i className="fab fa-google-plus-g"></i>
                                                </NavLink>
                                            </div>
                                        </div>
                                    </NavLink>
                                </div>
                                <div className="team-bottom-block p-4">
                                    <h5 className="member mb-1"><NavLink to="#team">Anton Bne</NavLink></h5>
                                    <small>Neuro Surgeon</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div className="w3l-homeblock2 py-5">
                <div className="container py-md-5 py-4">
                    <h3 className="title-style text-center mb-5">Latest <span>Blog</span> Posts</h3>
                    <div className="row">
                        <div className="col-lg-6">
                            <div className="bg-clr-white hover-box">
                                <div className="row align-items-center">
                                    <div className="col-sm-6 position-relative">
                                        <NavLink to="#blog">
                                            <img className="img-fluid d-block" src="/images/n1.jpg" alt=""/>
                                        </NavLink>
                                    </div>
                                    <div className="col-sm-6">
                                        <div className="card-body blog-details align-self pl-sm-0">
                                            <NavLink to="#blog" className="blog-desc">Neurosurgeons Putting Patients
                                                First
                                            </NavLink>
                                            <p>Lorem ipsum dolor sit amet consectetur ipsum adipisicing elit.</p>
                                            <div
                                                className="d-flex align-items-center justify-content-between mt-lg-4 mt-5">
                                                <h5 className="text-blog-e">July 22, 2022</h5>
                                                <NavLink to="#blog" className="blog-icon-e"><i
                                                    className="fas fa-plus"></i></NavLink>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6 mt-lg-0 mt-4">
                            <div className="bg-clr-white hover-box">
                                <div className="row align-items-center">
                                    <div className="col-sm-6 position-relative">
                                        <NavLink to="#blog">
                                            <img className="img-fluid d-block" src="/images/blog2.jpg"
                                                 alt="Card image cap"/>
                                        </NavLink>
                                    </div>
                                    <div className="col-sm-6">
                                        <div className="card-body blog-details align-self pl-sm-0">
                                            <NavLink to="#blog" className="blog-desc">Treatment with Great
                                                Care</NavLink>
                                            <p>Lorem ipsum dolor sit amet consectetur ipsum adipisicing elit.</p>
                                            <div
                                                className="d-flex align-items-center justify-content-between mt-lg-4 mt-5">
                                                <h5 className="text-blog-e">July 28, 2022</h5>
                                                <NavLink to="#blog" className="blog-icon-e"><i
                                                    className="fas fa-plus"></i></NavLink>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <section className="w3l-progress pt-5" id="progress">
                <div className="container pt-md-5 pt-4">
                    <div className="row align-items-center">
                        <div className="col-lg-6 pe-lg-5">
                            <div className="progress-info info1">
                                <h6 className="progress-tittle">Neurological Test <span className="">80%</span></h6>
                                <div className="progress">
                                    <div className="progress-bar progress-bar-striped gradient-1" role="progressbar"
                                         style={{width: '80%'}} aria-valuenow="90" aria-valuemin="0"
                                         aria-valuemax="100">
                                    </div>
                                </div>
                            </div>
                            <div className="progress-info info2">
                                <h6 className="progress-tittle">Cardiovascular Test <span className="">95%</span>
                                </h6>
                                <div className="progress">
                                    <div className="progress-bar progress-bar-striped gradient-2" role="progressbar"
                                         style={{width: '95%'}} aria-valuenow="95" aria-valuemin="0"
                                         aria-valuemax="100">
                                    </div>
                                </div>
                            </div>
                            <div className="progress-info info3">
                                <h6 className="progress-tittle">Gastrointestina test <span className="">60%</span></h6>
                                <div className="progress">
                                    <div className="progress-bar progress-bar-striped gradient-3" role="progressbar"
                                         style={{width: '60%'}} aria-valuenow="95" aria-valuemin="0"
                                         aria-valuemax="100">
                                    </div>
                                </div>
                            </div>
                            <div className="progress-info info4">
                                <h6 className="progress-tittle">Orthodontics <span className="">85%</span></h6>
                                <div className="progress">
                                    <div className="progress-bar progress-bar-striped gradient-4" role="progressbar"
                                         style={{width: '85%'}} aria-valuenow="95" aria-valuemin="0"
                                         aria-valuemax="100">
                                    </div>
                                </div>
                            </div>

                            <div className="progress-info info3">
                                <h6 className="progress-tittle">Ear, Nose & Throat <span className="">60%</span></h6>
                                <div className="progress">
                                    <div className="progress-bar progress-bar-striped gradient-3" role="progressbar"
                                         style={{width: '60%'}} aria-valuenow="95" aria-valuemin="0"
                                         aria-valuemax="100">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-lg-6 text-center">
                            <img src="/images/img1.png" alt="" className="img-fluid"/>
                        </div>
                    </div>
                </div>
            </section>

            <section className="w3l-call-to-action-6">
                <div className="container py-md-5 py-sm-4 py-5">
                    <div className="d-sm-flex align-items-center justify-content-between">
                        <div className="left-content-call">
                            <h3 className="title-big">Visit Now!</h3>
                            <p className="text-white mt-1">Begin the change today</p>
                        </div>
                        <div className="right-content-call mt-sm-0 mt-4">
                            <ul className="buttons">
                                <li className="phone-sec me-lg-4"><i className="fas fa-phone-volume"></i>
                                    <NavLink className="call-style-w3" to="tel:+91 6281115308">+91 6281115308</NavLink>
                                </li>
                                <li><NavLink to="appointment.html"
                                             className="btn btn-outline-primary btn-style btn-style-2 mt-lg-0 mt-3">Book
                                    Now</NavLink></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>

            <Link to={"/patient#home"}>
                <button id="movetop" title="Go to top">
                    <span className="fas fa-level-up-alt" aria-hidden="true"></span>
                </button>
            </Link>

        </>
    )
}