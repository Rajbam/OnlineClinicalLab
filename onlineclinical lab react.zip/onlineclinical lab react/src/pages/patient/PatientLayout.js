import {NavLink, Outlet} from "react-router-dom"
import axios from "axios";
import {useEffect, useState} from "react";

export default function PatientLayout() {
    let[userSession, setUserSession]=useState({});
    function logOutpatient() {
        axios.post("http://localhost:4000/patientlogout").then((response) => {
            console.log(response.data);
        }).catch((error) => {
            console.log(error);
        })
    }

    useEffect(() => {
        axios.get("http://localhost:4000/send-patient-session").then((response) =>{
            setUserSession(response.data);
        }).catch((error)=>{
            console.log(error);
        })
        },[]);

    return (
        <>

            {
                Object.keys(userSession).length > 0 &&

                <header id="site-header" className="fixed-top">
                    <div className="container">
                        <nav className="navbar navbar-expand-lg navbar-light">
                            <NavLink className="navbar-brand" to="index">
                                <i className="fas fa-heartbeat"></i>O. Clinic
                            </NavLink>
                            <button className="navbar-toggler collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#navbarScroll" aria-controls="navbarScroll"
                                    aria-expanded="false"
                                    aria-label="Toggle navigation">
                                <span className="navbar-toggler-icon fa icon-expand fa-bars"></span>
                                <span className="navbar-toggler-icon fa icon-close fa-times"></span>
                            </button>
                            <div className="collapse navbar-collapse" id="navbarScroll">
                                <ul className="navbar-nav ms-auto me-2 my-2 my-lg-0 navbar-nav-scroll">
                                    <li className="nav-item">
                                        <NavLink className="nav-link active" aria-current="page"
                                                 to=""><i className="fas fa-home"></i>  Home</NavLink>
                                    </li>
                                    <li className="nav-item">

                                        <NavLink className="nav-link" to="/patient/about"><i className="fas fa-info-circle"></i> About</NavLink>

                                    </li>
                                    <li className="nav-item">
                                        <NavLink className="nav-link" to="/patient/services"><i className="fas fa-wrench"></i> Services</NavLink>
                                    </li>
                                    <li className="nav-item">
                                        <NavLink className="nav-link" to="/patient/contact"><i className="fas fa-phone-volume"></i> Contact</NavLink>
                                    </li>
                                    {/*<li className="dropdown ">*/}
                                    {/*    <button type="button"*/}
                                    {/*            className="btn-transparent cursor-pointer dropdown-toggle"*/}
                                    {/*            data-bs-toggle="dropdown"><i className="fas fa-hand-holding-heart"></i>  Reports*/}
                                    {/*    </button>*/}
                                    {/*    <ul className="dropdown-menu">*/}
                                    {/*        <NavLink className="bg-custom" to="">New Reports</NavLink>*/}
                                    {/*        <NavLink className="bg-custom" to="">Old Reports</NavLink>*/}
                                    {/*    </ul>*/}
                                    {/*</li>*/}
                                    {/*<li className="nav-item">*/}
                                    {/*    <NavLink className="nav-link" to="about.html">About</NavLink>*/}
                                    {/*</li>*/}

                                    <li className="dropdown ">
                                        <button type="button"
                                                className="btn-transparent cursor-pointer dropdown-toggle"
                                                data-bs-toggle="dropdown"><i className="fas fa-user-check"></i> Profile
                                        </button>
                                        <ul className="dropdown-menu">
                                            <NavLink className="bg-custom" to="/patient/view-patient-test"><i className="fas fa-user-check"></i>View Profile</NavLink>
                                            <NavLink className="bg-custom" to="/patient/my-booking"><i className="fas fa-book"></i>My Bookings</NavLink>
                                        </ul>
                                    </li>

                                    <li className="nav-item">
                                        <NavLink className="nav-link"
                                                 to="/patient/patient-change-password"><i className="fas fa-key"></i>  ChangePassword</NavLink>
                                    </li>

                                    <li className="nav-item">
                                        <NavLink className="nav-link" to="/patient/patient-login" role={"button"}
                                                 onClick={logOutpatient}><i className="fa fa-sign-out-alt"></i>  LogOut</NavLink>
                                    </li>


                                </ul>

                            </div>

                            <div className="cont-ser-position">
                                <nav className="navigation">
                                    <div className="theme-switch-wrapper">
                                        <label className="theme-switch" htmlFor="checkbox">
                                            <input type="checkbox" id="checkbox"/>
                                            <div className="mode-container">
                                                <i className="gg-sun"></i>
                                                <i className="gg-moon"></i>
                                            </div>
                                        </label>
                                    </div>
                                </nav>
                            </div>

                        </nav>
                    </div>
                </header>
            }

            {
                Object.keys(userSession).length === 0 &&
                <header id="site-header" className="fixed-top">
                    <div className="container">
                        <nav className="navbar navbar-expand-lg navbar-light">
                            <NavLink className="navbar-brand" to="index">
                                <i className="fas fa-heartbeat"></i>O. Clinic
                            </NavLink>
                            <button className="navbar-toggler collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#navbarScroll" aria-controls="navbarScroll"
                                    aria-expanded="false"
                                    aria-label="Toggle navigation">
                                <span className="navbar-toggler-icon fa icon-expand fa-bars"></span>
                                <span className="navbar-toggler-icon fa icon-close fa-times"></span>
                            </button>
                            <div className="collapse navbar-collapse" id="navbarScroll">
                                <ul className="navbar-nav ms-auto me-2 my-2 my-lg-0 navbar-nav-scroll">
                                    <li className="nav-item">
                                        {/*<NavLink className="nav-link active" aria-current="page" to="index.html">Home</NavLink>*/}
                                        <NavLink className="nav-link active" aria-current="page"
                                                 to="/patient"><i className="fas fa-home"></i> Home</NavLink>
                                    </li>
                                    <li className="nav-item">
                                        {/*<NavLink className="nav-link" to="/patient/about">About</NavLink>*/}
                                        <NavLink className="nav-link" to="/patient/about"><i className="fas fa-info-circle"></i> About</NavLink>

                                    </li>
                                    <li className="nav-item">
                                        <NavLink className="nav-link" to="/patient/services"><i className="fas fa-wrench"></i> Services</NavLink>
                                    </li>
                                    <li className="nav-item">
                                        <NavLink className="nav-link" to="/patient/contact"><i className="fas fa-phone-volume"></i> Contact</NavLink>
                                    </li>
                                </ul>

                            </div>

                            <div className="cont-ser-position">
                                <nav className="navigation">
                                    <div className="theme-switch-wrapper">
                                        <label className="theme-switch" htmlFor="checkbox">
                                            <input type="checkbox" id="checkbox"/>
                                            <div className="mode-container">
                                                <i className="gg-sun"></i>
                                                <i className="gg-moon"></i>
                                            </div>
                                        </label>
                                    </div>
                                </nav>
                            </div>

                        </nav>
                    </div>
                </header>
            }



            <Outlet/>

            <footer className="w3l-footer-29-main">
                <div className="footer-29 pt-5 pb-4">
                    <div className="container pt-md-4">
                        <div className="row footer-top-29">
                            <div className="col-md-5 footer-list-29 pe-xl-5">
                                <h6 className="footer-title-29">Contact Info </h6>
                                <p className="mb-2 pe-xl-5"><i className="fa fa-address-card" aria-hidden="true"></i> Address : O.Clinic, 143115, Ranjit Avenue , Amritsar
                                </p>
                                <p className="mb-2"><i className="fas fa-phone-volume"></i> Phone Number : <NavLink to="tel:+91 8770658635">+91 8770658635</NavLink></p>
                                <p className="mb-2"><i className="fa fa-envelope" aria-hidden="true"></i> Email : <NavLink
                                    to="mailto:O.Clinic12@gmail.com">O.Clinic12@gmail.com</NavLink></p>
                            </div>
                            <div className="col-md-2 col-4 footer-list-29 mt-md-0 mt-4">
                                <ul>
                                    <h6 className="footer-title-29">About</h6>
                                    <li><NavLink  to="/patient/about">About Us</NavLink></li>
                                    <li><NavLink to="/patient/services">Services</NavLink></li>
                                    <li><NavLink to="/patient/contact">Special Offers</NavLink></li>
                                    <li><NavLink to="/patient">Orthodontics</NavLink></li>
                                </ul>
                            </div>
                            <div className="col-lg-3 col-md-3 col-4 ps-lg-5 ps-md-4 footer-list-29 mt-md-0 mt-4">
                                <ul>
                                    <h6 className="footer-title-29">Explore</h6>
                                    <li><NavLink to="#blog">Blog Posts</NavLink></li>
                                    <li><NavLink to="/patient/contact">Contact Us</NavLink></li>
                                    <li><NavLink to="#privacy">Privacy policy</NavLink></li>
                                    <li><NavLink to="#license">License & uses</NavLink></li>
                                </ul>
                            </div>
                            <div className="col-lg-2 col-md-2 col-4 footer-list-29 mt-md-0 mt-4">
                                <ul>
                                    <h6 className="footer-title-29">Doctors</h6>
                                    <li><NavLink to="#doctor">Dr. John Doe</NavLink></li>
                                    <li><NavLink to="#doctor">Dr. Martin Ker</NavLink></li>
                                    <li><NavLink to="#doctor">Dr. Alexander</NavLink></li>
                                    <li><NavLink to="#doctor">Dr. Eliz Wilson</NavLink></li>
                                </ul>
                            </div>
                        </div>

                        <p className="copy-footer-29 text-center pt-lg-2 mt-5 pb-2">© 2022 O.Clinic, All rights
                            reserved. Design by  <b>Paras Puri</b></p>

                    </div>
                </div>
            </footer>


        </>
    )
}