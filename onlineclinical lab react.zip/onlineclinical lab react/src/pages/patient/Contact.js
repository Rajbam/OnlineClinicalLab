import {NavLink, Outlet} from "react-router-dom"
import {useEffect, useState} from "react";
import axios from "axios";
import {useForm} from "react-hook-form";
import {ErrorMessage} from "@hookform/error-message";
import Swal from "sweetalert2";

export default function Contact() {
    let [email, contactEmail] = useState("");
    let {register, handleSubmit, formState: {errors}, reset, setValue} = useForm();

    useEffect(() => {
        axios.get("http://localhost:4000/send-patient-session").then((response) => {
            contactEmail(() => response.data);
            let contact_email = response.data;
            setValue("newmail", contact_email);

        }).catch((error) => {
            console.log(error);
        })
    }, []);

    function onSubmit(data) {
        console.log(data);
        // axios.post("http://localhost:4000/contact-details", data).then((response) => {
        //     if (response.data === "success") {
        //         reset();
        //         Swal.fire(
        //             'Details Added!',
        //             'Your query has been added.We will contact you soon.',
        //             'success'
        //         )
        //
        //     }
        // }).catch((error) => {
        //     console.log(error);
        // })
    }

    return (
        <>

            <section className="inner-banner py-5">
                <div className="w3l-breadcrumb py-lg-5">
                    <div className="container pt-4 pb-sm-4">
                        <h4 className="inner-text-title font-weight-bold pt-sm-5 pt-4">Contact Us</h4>
                        <ul className="breadcrumbs-custom-path">
                            <li><NavLink to="index.html">Home</NavLink></li>
                            <li className="active"><i className="fas fa-angle-right mx-2"></i>Contact</li>
                        </ul>
                    </div>
                </div>
            </section>

            <section className="w3l-contact-11 py-5" id="contact">
                <div className="container py-md-5 py-4">
                    <h3 className="title-style text-center mb-5"><span>Contact </span> Us</h3>
                    <div className="row text-center mb-5 pb-lg-5 pb-sm-4">
                        <div className="col-lg-3 col-sm-6 contact-info">
                            <i className="fas fa-map-marked-alt"></i>
                            <h4>Location</h4>
                            <p>India, Punjab, Amritsar, Ranjit Avenue, 143115 </p>
                        </div>
                        <div className="col-lg-3 col-sm-6 contact-info mt-md-0 mt-4">
                            <i className="fas fa-headset"></i>
                            <h4>Phone</h4>
                            <p><NavLink className="nav-link" to="tel:+91 8770658635">+91 8770658635</NavLink></p>
                        </div>
                        <div className="col-lg-3 col-sm-6 contact-info mt-lg-0 mt-4">
                            <i className="fas fa-envelope-open-text"></i>
                            <h4>Email</h4>
                            <p><NavLink to="mailto:O.Clinic12@gmail.com"
                                        className="nav-link">O.Clinic12@gmail.com</NavLink></p>
                        </div>
                        <div className="col-lg-3 col-sm-6 contact-info mt-lg-0 mt-4">
                            <i className="fas fa-user-clock"></i>
                            <h4>Working Hours</h4>
                            <p>24/7</p>
                        </div>
                    </div>
                    <div className="form-inner-cont mx-auto">
                        <form className="signin-form" onSubmit={handleSubmit(onSubmit)}>
                            <div className="row align-form-map">
                                {
                                    email === "" ? <>
                                        <div className="col-sm-6 form-input">
                                            <input {...register('newmail', {
                                                required: "You must specify email",
                                                pattern: {
                                                    value: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                                                    message: "Enter valid email"
                                                }
                                            })} type="email" placeholder="Email"
                                            />
                                        </div>
                                        <ErrorMessage name="newmail" errors={errors}
                                                      render={({message}) => <p className="text-danger">{message}</p>}/>
                                    </> : <>
                                        <div className="col-sm-6 form-input">
                                            <input {...register('newmail')} disabled type="email" placeholder="Email"
                                            />
                                        </div>
                                    </>
                                }
                                <div className="col-sm-6 form-input">
                                    <input {...register('uname', {
                                        required: "You must specify a username",
                                        minLength: {
                                            value: 8,
                                            message: "You must enter atleast 6 characters"
                                        },
                                        maxLength: {
                                            value: 19,
                                            message: "Please enter less than 20 characters"
                                        },

                                    })} type="text" placeholder="Name"/>
                                </div>
                                <ErrorMessage name="uname" errors={errors}
                                              render={({message}) => <p className="text-danger">{message}</p>}/>
                                <div className="col-sm-6 form-input">
                                    <input {...register('subject', {required: "this field is required"})} type="text"
                                           placeholder="Subject" className="contact-input"/>
                                </div>
                                <div className="col-sm-6 form-input">
                                    <input {...register('phonenumber', {
                                        required: "You must specify mobile number",
                                        pattern: {
                                            value: /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/,
                                            message: "Enter valid mobile number"
                                        }
                                    })} type="number" placeholder="Phone Number"
                                           className="contact-input"/>
                                </div>
                                <ErrorMessage name="phonenumber" errors={errors}
                                              render={({message}) => <p className="text-danger">{message}</p>}/>
                            </div>
                            <div className="form-input">
                                <textarea {...register('message', {required: "You must specify name"})}
                                          placeholder="Message"
                                ></textarea>
                            </div>
                            <ErrorMessage name="message" errors={errors}
                                          render={({message}) => <p className="text-danger">{message}</p>}/>
                            <div className="submit text-right">
                                <button type="submit" className="btn btn-outline-primary btn-style">Submit
                                    Message
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </section>

            <div className="map">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d12647.979897205161!2d74.85726360370239!3d31.655536001434985!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1668667926794!5m2!1sen!2sin"

                    width="100%" height="400" frameBorder="0" allowFullScreen="" title="myFrame"></iframe>
            </div>


            <button onClick="topFunction()" id="movetop" title="Go to top">
                <span className="fas fa-level-up-alt" aria-hidden="true"></span>
            </button>

            <Outlet/>

        </>
    )
}