import {NavLink, Outlet} from "react-router-dom"

export default function Services() {
    return(
        <>
            <section className="inner-banner py-5">
                <div className="w3l-breadcrumb py-lg-5">
                    <div className="container pt-4 pb-sm-4">
                        <h4 className="inner-text-title font-weight-bold pt-sm-5 pt-4">Our Services</h4>
                        <ul className="breadcrumbs-custom-path">
                            <li><NavLink to="index.html">Home</NavLink></li>
                            <li className="active"><i className="fas fa-angle-right mx-2"></i>Services</li>
                        </ul>
                    </div>
                </div>
            </section>

            <section className="w3l-homeblock7 py-5">
                <div className="container py-md-5 py-4">
                    <div className="row align-items-center">
                        <div className="col-lg-4">
                            <div className="pr-5">
                                <h3 className="title-big-2">Helps improve your smile</h3>
                                <p className="mt-4">Semper at tempufddfel. Lorem ipsum dolor, sit amet consectetur
                                    adipisicing elit.
                                    dignissimos quis</p>
                            </div>
                            <div className="pr-5 mt-lg-5 mt-4 sec-bor">
                                <h3 className="title-big-2 pt-lg-5 pt-4">Helps make you look younger</h3>
                                <p className="mt-4">Semper at tempufddfel. Lorem ipsum dolor, sit amet consectetur
                                    adipisicing elit.
                                    dignissimos quis</p>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-6 col-sm-8 text-center mt-lg-0 mt-5">
                            <img src="/images/service1.jpg" alt="" className="img-fluid radius-image"/>
                        </div>
                        <div className="col-lg-4 col-md-6 mt-lg-0 mt-5 text-lg-end">
                            <div className="pl-lg-5">
                                <h3 className="title-big-2">Boosts a person’s self esteem</h3>
                                <p className="mt-4">Semper at tempufddfel. Lorem ipsum dolor, sit amet consectetur
                                    adipisicing elit.
                                    dignissimos quis</p>
                            </div>
                            <div className="pl-lg-5 mt-lg-5 mt-4 sec-bor">
                                <h3 className="title-big-2 pt-lg-5 pt-4">Helps improve your appearance</h3>
                                <p className="mt-4">Semper at tempufddfel. Lorem ipsum dolor, sit amet consectetur
                                    adipisicing elit.
                                    dignissimos quis</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div className="service-section py-5">
                <div className="container py-md-5 py-4">
                    <h3 className="title-style text-center mb-sm-5 mb-4">Our <span>Services</span></h3>
                    <div className="row justify-content-center">
                        <div className="col-lg-3 col-md-6 item">
                            <div className="card">
                                <div className="card-header p-0 position-relative border-0">
                                    <NavLink to="/patient/services">
                                        <img className="d-block img-responsive" src="/images/c1.jpg"
                                             alt=""/>
                                    </NavLink>
                                </div>
                                <div className="card-body service-details">
                                    <h4 to="/patient/services" className="service-heading">Cardio Stress Test</h4>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 mt-md-0 mt-4 pt-md-0 pt-2">
                            <div className="card">
                                <div className="card-header p-0 position-relative border-0">
                                    <NavLink to="/patient/services">
                                        <img className="d-block img-responsive" src="/images/n2.jpg"
                                             alt=""/>
                                    </NavLink>
                                </div>
                                <div className="card-body service-details">
                                    <h4 to="/patient/services" className="service-heading">Aneurysm surgery</h4>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 mt-lg-0 mt-4 pt-lg-0 pt-2">
                            <div className="card">
                                <div className="card-header p-0 position-relative border-0">
                                    <NavLink to="/patient/services">
                                        <img className="d-block img-responsive" src="/images/n3.jpg"
                                             alt=""/>
                                    </NavLink>
                                </div>
                                <div className="card-body service-details">
                                    <h4 to="/patient/services" className="service-heading">Brain tumor surgery</h4>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 mt-lg-0 mt-4 pt-lg-0 pt-2">
                            <div className="card">
                                <div className="card-header p-0 position-relative border-0">
                                    <NavLink to="/patient/services">
                                        <img className="d-block img-responsive" src= "/images/b1.jpg"
                                             alt=""/>
                                    </NavLink>
                                </div>
                                <div className="card-body service-details">
                                    <h4 to="/patient/services" className="service-heading">Blood Test</h4>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 item mt-4 pt-2">
                            <div className="card">
                                <div className="card-header p-0 position-relative border-0">
                                    <NavLink to="/patient/services">
                                        <img className="d-block img-responsive" src="/images/b2.jpg"
                                             alt=""/>
                                    </NavLink>
                                </div>
                                <div className="card-body service-details">
                                    <h4 to="/patient/services" className="service-heading">Blood Sample</h4>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 mt-4 pt-2">
                            <div className="card">
                                <div className="card-header p-0 position-relative border-0">
                                    <NavLink to="/patient/services">
                                        <img className="d-block img-responsive" src="/images/s3.jpg"
                                             alt=""/>
                                    </NavLink>
                                </div>
                                <div className="card-body service-details">
                                    <h4 to="/patient/services" className="service-heading">Dental Cleaning</h4>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 mt-4 pt-2">
                            <div className="card">
                                <div className="card-header p-0 position-relative border-0">
                                    <NavLink to="/patient/services">
                                        <img className="d-block img-responsive" src="/images/s6.jpg"
                                             alt=""/>
                                    </NavLink>
                                </div>
                                <div className="card-body service-details">
                                    <h4 to="/patient/services" className="service-heading">Aligning the Teeth</h4>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 mt-4 pt-2">
                            <div className="card">
                                <div className="card-header p-0 position-relative border-0">
                                    <NavLink to="/patient/services">
                                        <img className="d-block img-responsive" src="/images/g1.jpg"
                                             alt=""/>
                                    </NavLink>
                                </div>
                                <div className="card-body service-details">
                                    <h4 to="/patient/services" className="service-heading">Gastrointestinal Test</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <section className="w3l-progress pt-5" id="progress">
                <div className="container pt-md-5 pt-4">
                    <div className="row align-items-center">
                        <div className="col-lg-6 pe-lg-5">
                            <div className="progress-info info1">
                                <h6 className="progress-tittle">Orthodontics <span className="">80%</span></h6>
                                <div className="progress">
                                    <div className="progress-bar progress-bar-striped gradient-1" role="progressbar"
                                         style={{width: '80%'}} aria-valuenow="90" aria-valuemin="0"
                                         aria-valuemax="100">
                                    </div>
                                </div>
                            </div>
                            <div className="progress-info info2">
                                <h6 className="progress-tittle">Cardiovascular Test <span className="">95%</span>
                                </h6>
                                <div className="progress">
                                    <div className="progress-bar progress-bar-striped gradient-2" role="progressbar"
                                         style={{width: '95%'}} aria-valuenow="95" aria-valuemin="0"
                                         aria-valuemax="100">
                                    </div>
                                </div>
                            </div>
                            <div className="progress-info info3">
                                <h6 className="progress-tittle">Gastrointestina test <span className="">60%</span></h6>
                                <div className="progress">
                                    <div className="progress-bar progress-bar-striped gradient-3" role="progressbar"
                                         style={{width: '60%'}} aria-valuenow="95" aria-valuemin="0"
                                         aria-valuemax="100">
                                    </div>
                                </div>
                            </div>
                            <div className="progress-info info4">
                                <h6 className="progress-tittle">Neurological Test <span className="">85%</span></h6>
                                <div className="progress">
                                    <div className="progress-bar progress-bar-striped gradient-4" role="progressbar"
                                         style={{width: '85%'}} aria-valuenow="95" aria-valuemin="0"
                                         aria-valuemax="100">
                                    </div>
                                </div>
                            </div>

                            <div className="progress-info info3">
                                <h6 className="progress-tittle">Ear, Nose & Throat <span className="">60%</span></h6>
                                <div className="progress">
                                    <div className="progress-bar progress-bar-striped gradient-3" role="progressbar"
                                         style={{width: '60%'}} aria-valuenow="95" aria-valuemin="0"
                                         aria-valuemax="100">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6 text-center">
                            <img src="/images/img1.png" alt="" className="img-fluid"/>
                        </div>
                    </div>
                </div>
            </section>

            <section className="w3l-call-to-action-6">
                <div className="container py-md-5 py-sm-4 py-5">
                    <div className="d-sm-flex align-items-center justify-content-between">
                        <div className="left-content-call">
                            <h3 className="title-big">Visit Now!</h3>
                            <p className="text-white mt-1">Begin the change today</p>
                        </div>
                        <div className="right-content-call mt-sm-0 mt-4">
                            <ul className="buttons">
                                <li className="phone-sec me-lg-4"><i className="fas fa-phone-volume"></i>
                                    <NavLink className="call-style-w3" to="tel:+91 6281115308">+91 6281115308</NavLink>
                                </li>
                                <li><NavLink to="/patient/patient-login" className="btn btn-style btn-style-2 mt-lg-0 mt-3">Book
                                    Now</NavLink></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>



            <button onClick="topFunction()" id="movetop" title="Go to top">
                <span className="fas fa-level-up-alt" aria-hidden="true"></span>
            </button>
            <Outlet/>

        </>
    )
}