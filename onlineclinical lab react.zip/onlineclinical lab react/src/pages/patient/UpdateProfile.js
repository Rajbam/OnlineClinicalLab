import {useNavigate, useParams} from "react-router-dom";
import Swal from "sweetalert2";
import {ErrorMessage} from "@hookform/error-message";
import axios from "axios";
import {useForm} from "react-hook-form";
import {useEffect, useState} from "react";
import Banner from "../../component/banner";
import { Button, Radio, RadioGroup, FormControlLabel, FormControl, FormLabel} from "@mui/material";

export default function UpdateProfile() {
    let navigate = useNavigate();
    let {p_id} = useParams();
    let [pid, setpid] = useState(null);
    let {register, handleSubmit, formState: {errors}, setValue, reset} = useForm();
    useEffect(() => {
        reset();
        axios.get(`http://localhost:4000/get-patient-profile-data-id${p_id}`).then((response) => {
            console.log(response.data);
            if (response.data === "error") {
                Swal.fire('Error!!', 'Some error occured in fetching details!!', 'error');
            } else {
                response.data.map((value, index) => {
                    let {
                        contact_email,
                        contact_no,
                        gender,
                        password,
                        p_address,
                        p_id,
                        p_name,


                    } = value;
                    setpid(p_id);
                    setValue("uname", p_name);
                    setValue("paddress", p_address);
                    setValue("newmail", contact_email);
                    setValue("password", password);
                    setValue("phonenumber", contact_no);
                    setValue("gender", gender);

                })
            }
        }).catch((error) => {
            console.log(error);
        })
    }, []);

    function onSubmit(data) {
        let {gender, newmail, paddress, password, phonenumber, uname} = data;
        let sendData = {
            gender,
            newmail,
            paddress,
            password,
            phonenumber,
            uname,
            pid: pid
        }
        axios.post("http://localhost:4000/patient-update-profile", sendData).then((response) => {
            if (response.data === "error") {
                Swal.fire('Error', 'Some technical error occured!!', 'error');
                navigate("/patient/view-patient-test");
            } else if (response.data === "success") {
                Swal.fire('Updated', 'Details have been updated successfully!!', 'success');
                navigate("/patient/view-patient-test");
            } else {
                Swal.fire('Error', 'Some error occured!!', 'error');
                navigate("/patient/view-patient-test");
            }
        }).catch((error) => {
            console.log(error);
        });
    }


    return (
        <>
        <Banner name={" Patient Details"} Previous={"Patient Home"}/>
    <section className="contact py-5 bg-img">
        <div>
            <div className="text-center mb-3">
                <h3 className={"style-font"}>Patient Details</h3>
            </div>
            <div className="form-inner-cont mx-auto container col-md-8 offset-md-2">
                <form onSubmit={handleSubmit(onSubmit)}>
                    <div className="row align-form-map">
                        <div className="col-sm-6 form-input">
                            <input {...register('uname', {
                                required: "You must specify a username",
                                minLength: {
                                    value: 8,
                                    message: "You must enter atleast 6 characters"
                                },
                                maxLength: {
                                    value: 19,
                                    message: "Please enter less than 20 characters"
                                },

                            })} type="text"
                                   className="form-control" placeholder="Enter Patient Name"/>
                        </div>
                        <ErrorMessage name="uname" errors={errors}
                                      render={({message}) => <p className="text-danger">{message}</p>}/>
                        <div className="col-sm-6 form-input">
                            <input {...register('newmail', {
                                required: "You must specify email",
                                pattern: {
                                    value: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                                    message: "Enter valid email"
                                }
                            })} type="text"
                                   className="form-control" placeholder="Enter Email"/>
                        </div>
                        <ErrorMessage name="newmail" errors={errors}
                                      render={({message}) => <p className="text-danger">{message}</p>}/>
                        <div className="col-sm-6 form-input">
                            <input {...register('paddress', {required: "You must specify name"})} type="text"
                                   className="form-control" placeholder="Enter PatientFullAddress"/>
                        </div>
                        <ErrorMessage name="paddress" errors={errors}
                                      render={({message}) => <p className="text-danger">{message}</p>}/>
                        <div className="col-sm-6 form-input">
                            <input {...register('password', {
                                required: "You must specify a password",
                                minLength: {
                                    value: 8,
                                    message: "Password must have at least 8 characters"
                                },
                                maxLength: {
                                    value: 12,
                                    message: "Please enter less than 13 characters"
                                }
                            })} type="password"
                                   className="form-control" placeholder="Enter Password"/>
                        </div>
                        <ErrorMessage name="password" errors={errors}
                                      render={({message}) => <p className="text-danger">{message}</p>}/>
                        <div className="col-sm-6 form-input">
                            <input {...register('phonenumber', {
                                required: "You must specify mobile number",
                                pattern: {
                                    value: /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/,
                                    message: "Enter valid mobile number"
                                }
                            })}
                                   type="text"
                                   className="form-control" placeholder="Enter mobile no"/>
                        </div>
                        <ErrorMessage name="phonenumber" errors={errors}
                                      render={({message}) => <p className="text-danger">{message}</p>}/>

                    </div>
                    <ErrorMessage name="type" errors={errors}
                                  render={({message}) => <p className="text-danger">{message}</p>}/>


                    <div className="col-sm-6 form-input">
                        <FormControl>
                            <FormLabel id="demo-row-radio-buttons-group-label">Gender</FormLabel>
                            <RadioGroup
                                row
                                aria-labelledby="demo-row-radio-buttons-group-label"
                                name="row-radio-buttons-group">

                                <FormControlLabel {...register('gender',
                                    {
                                        required: 'Please enter gender'
                                    }
                                )} value="female" control={<Radio/>} label="Female"/>

                                <FormControlLabel {...register('gender',
                                    {
                                        required: 'Please enter gender'
                                    }
                                )} value="male" control={<Radio/>} label="Male"/>

                            </RadioGroup>
                        </FormControl>

                        <ErrorMessage
                            name='gender'
                            errors={errors}
                            render={({message}) => <p className="text-danger">{message}</p>}/>
                    </div>

                    <div className={"d-flex justify-content-center"}>

                        <button className={"btn sent-butnn btn-primary mr-3"}>Update Profile</button>

                    </div>
                </form>
            </div>
        </div>
    </section>
            </>
    )
}
