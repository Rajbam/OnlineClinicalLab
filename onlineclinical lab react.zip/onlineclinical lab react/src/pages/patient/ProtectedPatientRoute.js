import { useEffect} from "react";
import {useNavigate} from "react-router-dom";
import axios from "axios";



export default function ProtectedPatientRoute({Component}) {
    let navigate = useNavigate();

    useEffect(() => {
        axios.get("http://localhost:4000/check-patient-session").then((response) => {
            if (response.data === "failed") {
                navigate("/patient/patient-login");
            }
        }).catch((error) => {
            console.log(error);
        })
    }, []);
    return (

           <Component/>

    )
}