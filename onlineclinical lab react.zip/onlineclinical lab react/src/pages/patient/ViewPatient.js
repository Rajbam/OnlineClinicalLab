import {useNavigate} from "react-router-dom";
import axios from "axios";
import {useEffect, useState} from "react";
import ReactLoading from 'react-loading';
import { FaUserEdit} from "react-icons/fa";
import Banner from "../../component/banner";

export default function ViewPatient() {
    let navigate = useNavigate();
    let [data, setData] = useState([]);
    let [stat, setStat] = useState(false);

    function getData() {
        setStat(false);
        axios.get("http://localhost:4000/getpatientprofile").then((response) => {
            console.log(response.data)
            setTimeout(() => {
                if (response.data !== "nodata") {
                    setData(response.data);
                    setStat(true);
                } else if (response.data === "nodata") {
                    setData([]);
                    setStat(true);
                }
            }, 3000)
        }).catch((error) => {
            console.log(error);
        })
    }

    useEffect(() => {
        getData();
    }, []);

    return (
        <>
            <Banner name={" View Patient"} Previous={"Patient Home"}/>
            {
                stat ?
                    data.length === 0 ?
                        <div className={"custom-flex container bg-inactive"}><h1
                            className={"custom-flex pt-5 font height-view"}>No Data
                            Found!!</h1>
                        </div> :
                        <section className="ftco-section">
                            <div className="container">
                                <div className="row justify-content-center">
                                    <div className="col-md-6 text-center mb-5">
                                        <h2 className="style-font">PATIENT DETAILS</h2>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-12">
                                        <div className="table-wrap" style={{overflow: "auto"}}>
                                            <table className="table table-responsive-xl">
                                                <thead>
                                                <tr>
                                                    <th>Fullname</th>
                                                    <th>Address</th>
                                                    <th>Email</th>
                                                    <th>Password</th>
                                                    <th>PhoneNumber</th>
                                                    <th>Gender</th>
                                                    <th colSpan={"2"} className={"text-center"}>Actions</th>


                                                </tr>
                                                </thead>
                                                <tbody>
                                                {
                                                    data.map((value, index) => {
                                                        let {
                                                            p_id,
                                                            p_name,
                                                            p_address,
                                                            contact_email,
                                                            password,
                                                            contact_no,
                                                            gender,


                                                        } = value;
                                                        return (
                                                            <tr key={index}>

                                                                <td>{p_name}</td>
                                                                <td>{p_address}</td>
                                                                <td>{contact_email}</td>
                                                                <td>{password}</td>
                                                                <td>{contact_no}</td>
                                                                <td>{gender}</td>


                                                                <td className='text-center'>
                                                                    <button onClick={() => {
                                                                        navigate(`/patient/patient-update-profile/${p_id}`)
                                                                    }} type={"button"} className={"btn btn-warning"}>Update <FaUserEdit/>
                                                                    </button>
                                                                </td>

                                                            </tr>
                                                        )
                                                    })
                                                }
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section> :
                    <>
                        <div className={"custom-flex"}><h1 className={"font"}>Fetching Data</h1><ReactLoading
                            className={"d-flex justify-content-center"}
                            type={"balls"} color={"darkred"} height={800} width={90}/>
                        </div>
                    </>
            }
        </>
    )
}