import {NavLink, Outlet} from "react-router-dom"

export default function About() {
    return(
        <>

            <section className="inner-banner py-5">
                <div className="w3l-breadcrumb py-lg-5">
                    <div className="container pt-4 pb-sm-4">
                        <h4 className="inner-text-title font-weight-bold pt-sm-5 pt-4">About Us</h4>
                        <ul className="breadcrumbs-custom-path">
                            <li><NavLink to="index.html">Home</NavLink></li>
                            <li className="active"><i className="fas fa-angle-right mx-2"></i>About</li>
                        </ul>
                    </div>
                </div>
            </section>

            <section className="w3l-homeblock1 py-5" id="about">
                <div className="container py-md-5 py-4">
                    <div className="row align-items-center">
                        <div className="col-lg-6 pe-xl-5">
                            <h3 className="title-style mb-3">Welcome to <span>O.Clinic</span></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad, quis nostrud
                                ullamco laboris nisi ut ex ea. </p>
                            <div className="mt-4">
                                <ul className="service-list">
                                    <li className="service-link"><NavLink to="#url"><i className="fas fa-check-circle"></i>Exceptional
                                        Service</NavLink></li>
                                    <li className="service-link"><NavLink to="#url"><i className="fas fa-check-circle"></i>Soft
                                        & Gentle</NavLink>
                                    </li>
                                </ul>
                            </div>
                            <NavLink to="/patient/about" className="btn btn-style mt-4">Discover More</NavLink>
                        </div>
                        <div className="col-lg-6 homeaboutblock mt-lg-0 mt-5">
                            <img src="/images/about.jpg" className="img-fluid radius-image" alt=""/>
                        </div>
                    </div>
                </div>
            </section>

            <section className="w3l-features py-5" id="features">
                <div className="container py-md-5 py-4">
                    <h3 className="title-style text-center text-white mb-sm-5 mb-4">Our Awesome <span>Features</span></h3>
                    <div className="row text-center">
                        <div className="col-lg-4 col-sm-6">
                            <div className="feature-gd feature-gd-2">
                                <div className="icon">
                                    <i className="fas fa-hand-holding-medical"></i>
                                </div>
                                <div className="icon-info">
                                    <h5><NavLink to="#features">The Quality of Used Medical Materials</NavLink></h5>
                                    <p> Lorem ipsum dolor sit amet, sed eiusmod
                                        temporinit sit.</p>
                                    <NavLink to="/patient/services" className="btn btn-style-primary">Learn More<i
                                        className="fas fa-arrow-right"></i></NavLink>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-sm-6 mt-sm-0 mt-4">
                            <div className="feature-gd feature-gd-2">
                                <div className="icon">
                                    <i className="fas fa-tooth"></i>
                                </div>
                                <div className="icon-info">
                                    <h5><NavLink to="#features">Dental Implants-New Teeth in One Day</NavLink></h5>
                                    <p> Lorem ipsum dolor sit amet, sed eiusmod
                                        temporinit sit.</p>
                                    <NavLink to="/patient/services" className="btn btn-style-primary">Learn More<i
                                        className="fas fa-arrow-right"></i></NavLink>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-sm-6 mt-lg-0 mt-sm-5 mt-4">
                            <div className="feature-gd feature-gd-2">
                                <div className="icon">
                                    <i className="fas fa-briefcase-medical"></i>
                                </div>
                                <div className="icon-info">
                                    <h5><NavLink to="#features">A Full Range of Dental Services</NavLink></h5>
                                    <p> Lorem ipsum dolor sit amet, sed eiusmod
                                        temporinit sit.</p>
                                    <NavLink to="/patient/services" className="btn btn-style-primary">Learn More<i
                                        className="fas fa-arrow-right"></i></NavLink>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-sm-6 mt-sm-5 mt-4">
                            <div className="feature-gd feature-gd-2">
                                <div className="icon">
                                    <i className="far fa-money-bill-alt"></i>
                                </div>
                                <div className="icon-info">
                                    <h5><NavLink to="#features">Loyalty Discounts of Regular Customers</NavLink></h5>
                                    <p> Lorem ipsum dolor sit amet, sed eiusmod
                                        temporinit sit.</p>
                                    <NavLink to="/patient/services" className="btn btn-style-primary">Learn More<i
                                        className="fas fa-arrow-right"></i></NavLink>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-sm-6 mt-sm-5 mt-4">
                            <div className="feature-gd feature-gd-2">
                                <div className="icon">
                                    <i className="fas fa-syringe"></i>
                                </div>
                                <div className="icon-info">
                                    <h5><NavLink to="#features">Dental Implants-New Teeth in One Day</NavLink></h5>
                                    <p> Lorem ipsum dolor sit amet, sed eiusmod
                                        temporinit sit.</p>
                                    <NavLink to="/patient/services" className="btn btn-style-primary">Learn More<i
                                        className="fas fa-arrow-right"></i></NavLink>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-sm-6 mt-sm-5 mt-4">
                            <div className="feature-gd feature-gd-2">
                                <div className="icon">
                                    <i className="fas fa-teeth-open"></i>
                                </div>
                                <div className="icon-info">
                                    <h5><NavLink to="#features">Modern Methods of Teeth Straightening</NavLink></h5>
                                    <p> Lorem ipsum dolor sit amet, sed eiusmod
                                        temporinit sit.</p>
                                    <NavLink to="/patient/services" className="btn btn-style-primary">Learn More<i
                                        className="fas fa-arrow-right"></i></NavLink>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="w3l-team py-5">
                <div className="container py-md-5 py-4">
                    <h3 className="title-style text-center mb-5">Meet Our <span>Doctors</span></h3>
                    <div className="row text-center">
                        <div className="col-lg-3 col-sm-6">
                            <div className="team-block-single">
                                <div className="team-grids">
                                    <NavLink to="#team-single">
                                        <img src="/images/team1.jpg" className="img-fluid" alt=""/>
                                        <div className="team-info">
                                            <div className="social-icons-section">
                                                <NavLink className="fac" to="#facebook">
                                                    <i className="fab fa-facebook-f"></i>
                                                </NavLink>
                                                <NavLink className="twitter mx-2" to="#twitter">
                                                    <i className="fab fa-twitter"></i>
                                                </NavLink>
                                                <NavLink className="google" to="#google-plus">
                                                    <i className="fab fa-google-plus-g"></i>
                                                </NavLink>
                                            </div>
                                        </div>
                                    </NavLink>
                                </div>
                                <div className="team-bottom-block p-4">
                                    <h5 className="member mb-1"><NavLink to="#team">Olive Yew</NavLink></h5>
                                    <small>Dentist</small>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-sm-6 mt-sm-0 mt-4">
                            <div className="team-block-single">
                                <div className="team-grids">
                                    <NavLink to="#team-single">
                                        <img src="/images/team2.jpg" className="img-fluid" alt=""/>
                                        <div className="team-info">
                                            <div className="social-icons-section">
                                                <NavLink className="fac" to="#facebook">
                                                    <i className="fab fa-facebook-f"></i>
                                                </NavLink>
                                                <NavLink className="twitter mx-2" to="#twitter">
                                                    <i className="fab fa-twitter"></i>
                                                </NavLink>
                                                <NavLink className="google" to="#google-plus">
                                                    <i className="fab fa-google-plus-g"></i>
                                                </NavLink>
                                            </div>
                                        </div>
                                    </NavLink>
                                </div>
                                <div className="team-bottom-block p-4">
                                    <h5 className="member mb-1 active"><NavLink to="#team">Aida Joe</NavLink></h5>
                                    <small>Orthodontist</small>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-sm-6 mt-lg-0 mt-4">
                            <div className="team-block-single">
                                <div className="team-grids">
                                    <NavLink to="#team-single">
                                        <img src="/images/team3.jpg" className="img-fluid" alt=""/>
                                        <div className="team-info">
                                            <div className="social-icons-section">
                                                <NavLink className="fac" to="#facebook">
                                                    <i className="fab fa-facebook-f"></i>
                                                </NavLink>
                                                <NavLink className="twitter mx-2" to="#twitter">
                                                    <i className="fab fa-twitter"></i>
                                                </NavLink>
                                                <NavLink className="google" to="#google-plus">
                                                    <i className="fab fa-google-plus-g"></i>
                                                </NavLink>
                                            </div>
                                        </div>
                                    </NavLink>
                                </div>
                                <div className="team-bottom-block p-4">
                                    <h5 className="member mb-1"><NavLink to="#team">Teri Dac</NavLink></h5>
                                    <small>Hygienist</small>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-sm-6 mt-lg-0 mt-4">
                            <div className="team-block-single">
                                <div className="team-grids">
                                    <NavLink to="#team-single">
                                        <img src="/images/team4.jpg" className="img-fluid" alt=""/>
                                        <div className="team-info">
                                            <div className="social-icons-section">
                                                <NavLink className="fac" to="#facebook">
                                                    <i className="fab fa-facebook-f"></i>
                                                </NavLink>
                                                <NavLink className="twitter mx-2" to="#twitter">
                                                    <i className="fab fa-twitter"></i>
                                                </NavLink>
                                                <NavLink className="google" to="#google-plus">
                                                    <i className="fab fa-google-plus-g"></i>
                                                </NavLink>
                                            </div>
                                        </div>
                                    </NavLink>
                                </div>
                                <div className="team-bottom-block p-4">
                                    <h5 className="member mb-1"><NavLink to="#team">Anton Bne</NavLink></h5>
                                    <small>Dentist</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="w3l-testimonials pb-5" id="testimonials">
                <div className="container py-md-5 py-4">
                    <h3 className="title-style text-center mb-5">What Our <span>Patients</span> Say!</h3>
                    <div className="owl-testimonial owl-carousel owl-theme mx-auto" >
                        <div className="item">
                            <div className="slider-info">
                                <div className="img-circle">
                                    <img src="/images/testi1.jpg" className="img-fluid rounded" alt=""/>
                                </div>
                                <div className="message-info">
                                    <span className="fa fa-quote-left mr-2"></span>
                                    <div className="message">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea sit
                                        id
                                        accusantium officia quod quasi necessitatibus perspiciatis Harum error provident
                                        quibusdam tenetur dolor sit amet.Nulla mollis dapibus nunc, ut rhoncus turpis
                                        sodales
                                        quis. Integer sit amet mattis quam. Lorem ipsum, dolor sit
                                        amet consectetur adipisicing elit.
                                    </div>
                                    <div className="name">- Johnson</div>
                                    <div className="desp ms-2">Businessman</div>
                                </div>
                            </div>
                        </div>
                        <div className="item">
                            <div className="slider-info">
                                <div className="img-circle">
                                    <img src="/images/testi2.jpg" className="img-fluid rounded" alt=""/>
                                </div>
                                <div className="message-info">
                                    <span className="fa fa-quote-left mr-2"></span>
                                    <div className="message">Hpsum dolor sit amet consectetur adipisicing elit. Ea sit id
                                        accusantium
                                        officia quod quasi necessitatibus perspiciatis Harum error provident
                                        quibusdam tenetur.Nulla mollis dapibus nunc, ut rhoncus turpis sodales quis. Integer
                                        sit
                                        amet mattis quam.consectetur adipisicing elit.Lorem ipsum, dolor sit amet
                                        consectetur
                                        adipisicing elit.
                                    </div>
                                    <div className="name">- Sami Wade</div>
                                    <div className="desp ms-2">Manager</div>
                                </div>
                            </div>
                        </div>
                        <div className="item">
                            <div className="slider-info">
                                <div className="img-circle">
                                    <img src="/images/testi3.jpg" className="img-fluid rounded" alt=""/>
                                </div>
                                <div className="message-info">
                                    <span className="fa fa-quote-left mr-2"></span>
                                    <div className="message">Morem ipsum dolor sit amet consectetur adipisicing elit. Ea sit
                                        id
                                        accusantium
                                        officia quod quasi necessitatibus perspiciatis Harum error provident
                                        quibusdam tenetur.Nulla mollis dapibus nunc, ut rhoncus turpis sodales quis. Integer
                                        sit
                                        amet mattis quam.consectetur adipisicing elitLorem ipsum, dolor sit amet consectetur
                                        adipisicing elit.
                                    </div>
                                    <div className="name">- Smith roy</div>
                                    <div className="desp ms-2">Employee</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="w3l-call-to-action-6">
                <div className="container py-md-5 py-sm-4 py-5">
                    <div className="d-sm-flex align-items-center justify-content-between">
                        <div className="left-content-call">
                            <h3 className="title-big">Visit Now!</h3>
                            <p className="text-white mt-1">Begin the change today</p>
                        </div>
                        <div className="right-content-call mt-sm-0 mt-4">
                            <ul className="buttons">
                                <li className="phone-sec me-lg-4"><i className="fas fa-phone-volume"></i>
                                    <NavLink className="call-style-w3" to="tel:+91 6281115308">+91 6281115308</NavLink>
                                </li>
                                <li><NavLink to="appointment.html" className="btn btn-style btn-style-2 mt-lg-0 mt-3">Book
                                    Now</NavLink></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>



            <button onClick="topFunction()" id="movetop" title="Go to top">
                <span className="fas fa-level-up-alt" aria-hidden="true"></span>
            </button>

            <Outlet/>

        </>

    )
}