import {FaCheckCircle} from "react-icons/fa";
import {useNavigate} from "react-router-dom";

export default function ThankuPage() {
    let navigate= useNavigate();
    return(
        <>
            
          
            <div className="vh-40 d-flex justify-content-center align-items-center">
                <div className="col-md-12">
                    <div className="border border-3 border-success"></div>
                    <div className="card  bg-white shadow p-5">
                        <div className="mb-4 text-center">
                            <FaCheckCircle size={"5rem"} color={"green"}/>
                        </div>
                        <div className="text-center">
                            <h1>Thank You !</h1>
                            <p>We've have received your lab test request. Please visit our lab ASAP and give your required test samples. </p>
                            <button className="btn btn-outline-primary" onClick={()=>{navigate("/patient")}} >Back Home</button>
                            <button className="btn btn-outline-primary" style={{marginLeft:"10px"}} onClick={()=>{navigate("/patient/my-booking")}} >My Bookings</button>
                        </div>
                    </div>
                </div>
            </div>
            
        </>
)}