import {useForm} from "react-hook-form";
import {useParams} from "react-router-dom";
import {useEffect, useState} from "react";
import axios from "axios";
import {useNavigate} from "react-router-dom";

export default function Cart() {
    let [Testname, setTestName] = useState(null);
    let navigate = useNavigate();
    let [Description, setDesCription] = useState(null);
    let [Category, setCategory] = useState(null);
    let [Price, setPrice] = useState(null);
    let [Userid, setUserId] = useState(null);
    let {register, handleSubmit, formState: {errors}, setValue, getValues} = useForm();
    let {lt_id} = useParams();
    let [userData, setUserData] = useState([]);

    useEffect(() => {
        //     axios.get("http://localhost:4000/show-data").then((response) =>{
        //         response.data.map((value,index)=>{
        //             let{p_id}=value;
        //             setUserId(p_id);
        //         })
        //
        //     })
        axios.get(`http://localhost:4000/show-data-at-checkout${lt_id}`).then((response) => {
            setUserData(response.data);
            response.data.map((value, index) => {
                let {
                    category,
                    description,
                    price,
                    test_name

                } = value;
                setPrice(price);
                setCategory(category);
                setDesCription(description);
                setTestName(test_name);
            })
        }).catch((error) => {
            console.log(error);
        })
    }, []);


    function book() {
        let data = {
            Price,
            Category,
            Description,
            Testname
        }
        console.log(data);
        axios.post("http://localhost:4000/cart-patient", data).then((response) => {
            navigate("/patient/checkout", {
                state: {
                    Testname: Testname,
                    Category: Category,
                    Price: Price,
                    Description: Description,
                    lt_id: lt_id
                }
            });
        }).catch((error) => {
            console.log(error);
        })
    }

    return (
        <>
            <section className="vh-100" style={{backgroundColor: "rgb(152 163 203)"}}>
                <div className="container h-100">
                    <div className="row d-flex justify-content-center align-items-center h-100">
                        <div className="col">
                            <p><span className="h2">Test Details </span><span
                                className="h4"></span></p>
                            {
                                userData.map((value, index) => {
                                    let {
                                        category,
                                        description,
                                        price,
                                        test_name

                                    } = value;
                                    return (
                                        <>
                                            <div className="card mb-4">
                                                <div className="card-body p-4">

                                                    <div className="row align-items-center">

                                                        <div className="col-md-2 d-flex justify-content-center">
                                                            <div>
                                                                <p className="small text-muted mb-4 pb-2">Name</p>
                                                                <p className="lead fw-normal mb-0">{test_name}</p>
                                                            </div>
                                                        </div>
                                                        <div className="col-md-2 d-flex justify-content-center">
                                                            <div>
                                                                <p className="small text-muted mb-4 pb-2">Description</p>
                                                                <p className="lead fw-normal mb-0">
                                                                    {/*<i*/}
                                                                    {/*    className="fas fa-circle me-2"*/}
                                                                    {/*    style={{color:"#fdd8d2"}}></i>*/}
                                                                    {description}</p>
                                                            </div>
                                                        </div>
                                                        <div className="col-md-2 d-flex justify-content-center">
                                                            <div>
                                                                <p className="small text-muted mb-4 pb-2">Category</p>
                                                                <p className="lead fw-normal mb-0">{category}</p>
                                                            </div>
                                                        </div>
                                                        <div className="col-md-2 d-flex justify-content-center">
                                                            <div>
                                                                <p className="small text-muted mb-4 pb-2">Price</p>
                                                                <p className="lead fw-normal mb-0">&#8377;{price}</p>
                                                            </div>
                                                        </div>
                                                        <div className="col-md-2 d-flex justify-content-center">
                                                            <div>
                                                                <p className="small text-muted mb-4 pb-2">Total</p>
                                                                <p className="lead fw-normal mb-0">&#8377;{price}</p>
                                                            </div>
                                                        </div>
                                                        <div className="col-md-2 d-flex justify-content-center">
                                                            <div>
                                                                <p className="small text-muted mb-4 pb-2">Payment</p>
                                                                <p className="lead fw-normal mb-0">Pending</p>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>

                                            <div className="card mb-5">
                                                <div className="card-body p-4">

                                                    <div className="float-end">
                                                        <p className="mb-0 me-5 d-flex align-items-center">
                                                            <span className="small text-muted me-2">Order total:</span>
                                                            <span
                                                                className="lead fw-normal">&#8377;{price}</span>
                                                        </p>
                                                    </div>

                                                </div>
                                            </div>

                                            <div className="d-flex justify-content-end">

                                                <button onClick={() => {
                                                    book()
                                                }} className="btn btn-primary btn-lg">Book Now
                                                </button>
                                            </div>
                                        </>
                                    )
                                })
                            }

                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}