import {useContext, useEffect} from "react";
import axios from "axios";
import {useForm} from "react-hook-form";
import {useLocation, useNavigate} from "react-router-dom";
import Swal from "sweetalert2";

// Import the package
import useRazorpay from "react-razorpay";

export default function CheckOut() {
    const Razorpay = useRazorpay();

    let navigate = useNavigate();
    let location = useLocation();

    let test_name = location.state.Testname;
    let category = location.state.Category;
    let price = location.state.Price;
    let lt_id = location.state.lt_id;
    let description = location.state.Description;

    let {
        register,
        handleSubmit,
        formState: {errors},
        reset,
        setValue,
    } = useForm();

    setValue("test_name", test_name);
    setValue("category", category);
    setValue("price", price);
    setValue("description", description);

    useEffect(() => {
        axios
            .get("http://localhost:4000/get-patient-data-checkout")
            .then((response) => {
                response.data.map((value, index) => {
                    let {p_id, p_name, p_address, contact_no, contact_email, gender} =
                        value;
                    setValue("p_id", p_id);
                    setValue("p_name", p_name);
                    setValue("p_address", p_address);
                    setValue("contact_email", contact_email);
                    setValue("contact_no", contact_no);
                    setValue("gender", gender);
                });
            })
            .catch((error) => {
                console.log(error);
            });
    }, []);

    const bookOrder = (response) => {
        let payment_id = response.razorpay_payment_id;
        if (payment_id !== "") {
            placeOrder("Payment Complete");
        } else {
            alert("Payment Failed. Try again...");
        }
    };

    /* RAZORPAY Options */
    let options = {
        key: "rzp_test_A3RM3Asww6uWvF",
        currency: "INR",
        amount: 0,
        name: "Voyage Ventures",
        description: "Airbnb",
        image:
            "https://i.pinimg.com/originals/c1/92/9d/c1929d3492c2f64ab65b43808c072043.jpg",
        handler: bookOrder,
        prefill: {
            name: "",
            email: "",
            contact: "",
        },
        theme: {
            color: "#F46432",
        },
    };

    const placeOrder = (status) => {
        let data = JSON.parse(localStorage.getItem("billingInfo"));
        // console.log(data);

        let {
            contact_email,
            contact_no,
            test_name,
            category,
            price,
            payment_method,
        } = data;

        let finalData = {
            contact_email,
            contact_no,
            test_name,
            category,
            price,
            payment_method,
            status,
            lt_id,
        };

        axios.post("http://localhost:4000/add-bill", finalData).then((response) => {
            if (response.data === "success") {
                navigate("/patient/thank-you");
            } else {
                Swal.fire("OOPS!!", "Some Error Occured", "error");
            }
        });
    };

    function OnSubmit(data) {
        localStorage.setItem("billingInfo", JSON.stringify(data));
        // console.log(data);
        let {
            contact_email,
            contact_no,
            test_name,
            category,
            price,
            payment_method,
        } = data;

        /* COD */
        if (payment_method === "cod") {


            placeOrder("Payment Pending");

        } else {

            options.amount = price * 100;
            options.prefill.email = contact_email;
            options.prefill.contact = contact_no;
            let rzp = new Razorpay(options);
            rzp.open();
        }
    }

    return (
        <>
            <section className="banner_inner" id="home">
                <div className="banner_inner_overlay"></div>
            </section>
            <div>
                <div className="py-3">
                    <div className="container">
                        <h1 className="text-light-primary my-2 text-center bg-dark col-6 rounded fw-bold text-light mx-auto">
                            Checkout
                        </h1>
                    </div>
                </div>
                <div className="py-4">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-10 offset-md-1">
                                <div className="card">
                                    <div className="card-header">
                                        <h4>Basic Information</h4>
                                    </div>
                                    <div className="card-body">
                                        <form onSubmit={handleSubmit(OnSubmit)}>
                                            <div className="row">
                                                <div className="col-md-6">
                                                    <div className="form-group mb-3">
                                                        <label htmlFor="p_id">Id Number</label>
                                                        <input
                                                            {...register("p_id")}
                                                            type={"text"}
                                                            disabled
                                                            className="form-control"
                                                        />
                                                    </div>
                                                </div>
                                                <div className="col-md-6">
                                                    <div className="form-group mb-3">
                                                        <label htmlFor="p_name">User Name</label>
                                                        <input
                                                            {...register("p_name")}
                                                            disabled
                                                            type="text"
                                                            className="form-control"
                                                        />
                                                    </div>
                                                </div>
                                                <div className="col-md-6">
                                                    <div className="form-group mb-3">
                                                        <label htmlFor="contact_email">Email</label>
                                                        <input
                                                            {...register("contact_email")}
                                                            disabled
                                                            type="email"
                                                            className="form-control"
                                                        />
                                                    </div>
                                                </div>
                                                <div className="col-md-6">
                                                    <div className="form-group mb-3">
                                                        <label htmlFor="p_address">Address</label>
                                                        <input
                                                            {...register("p_address")}
                                                            disabled
                                                            type="text"
                                                            className="form-control"
                                                        />
                                                    </div>
                                                </div>

                                                <div className="col-md-6">
                                                    <div className="form-group mb-3">
                                                        <label htmlFor="contact_no">Contact number</label>
                                                        <input
                                                            disabled
                                                            {...register("contact_no")}
                                                            type="number"
                                                            className="form-control"
                                                        />
                                                    </div>
                                                </div>
                                                <div className="col-md-6">
                                                    <div className="form-group mb-3">
                                                        <label htmlFor="gender">Gender</label>
                                                        <input
                                                            disabled
                                                            {...register("gender")}
                                                            type="text"
                                                            className="form-control"
                                                        />
                                                    </div>
                                                </div>
                                                <div className="col-md-6">
                                                    <div className="form-group mb-3">
                                                        <label htmlFor="gender">Testname</label>
                                                        <input
                                                            disabled
                                                            {...register("test_name")}
                                                            type="text"
                                                            className="form-control"
                                                        />
                                                    </div>
                                                </div>
                                                <div className="col-md-6">
                                                    <div className="form-group mb-3">
                                                        <label htmlFor="gender">Category</label>
                                                        <input
                                                            disabled
                                                            {...register("category")}
                                                            type="text"
                                                            className="form-control"
                                                        />
                                                    </div>
                                                </div>
                                                <div className="col-md-6">
                                                    <div className="form-group mb-3">
                                                        <label htmlFor="gender">Description</label>
                                                        <input
                                                            disabled
                                                            {...register("description")}
                                                            type="text"
                                                            className="form-control"
                                                        />
                                                    </div>
                                                </div>
                                                <div className="col-md-6">
                                                    <div className="form-group mb-3">
                                                        <label htmlFor="gender">Price</label>
                                                        <input
                                                            disabled
                                                            {...register("price")}
                                                            type="text"
                                                            className="form-control"
                                                        />
                                                    </div>
                                                </div>

                                                <br/>
                                                <div className="col-md-12 mb-1">
                                                    <b>Payment Methods : </b>
                                                </div>
                                                <div className="col-md-4">
                                                    <label htmlFor="Cod" className="me-1">
                                                        Cash On Delivery
                                                    </label>
                                                    <input
                                                        type="radio"
                                                        className="radio-button"
                                                        {...register("payment_method")}
                                                        value="cod"
                                                        id="Cod"
                                                    />
                                                </div>

                                                <div className="col-md-4">
                                                    <label htmlFor="Online" className="me-1">
                                                        Online Payment
                                                    </label>
                                                    <input
                                                        className="radio-button"
                                                        {...register("payment_method")}
                                                        type="radio"
                                                        value="online"
                                                        id="Online"
                                                    />
                                                </div>
                                                <div className="col-md-12">
                                                    <div className="form-group">
                                                        <label htmlFor=""></label>
                                                        <button className="btn btn-primary col-12 mt-4">
                                                            Place Order
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            {/*<div className="col-md-5">*/}
                            {/*    <table className="table table-bordered reset_table">*/}
                            {/*        <thead>*/}
                            {/*        <tr>*/}
                            {/*            <th>Property</th>*/}
                            {/*            <th>Rooms</th>*/}
                            {/*            <th>Price(inc. of days)</th>*/}
                            {/*            <th>Total</th>*/}
                            {/*        </tr>*/}
                            {/*        </thead>*/}
                            {/*        <tbody>*/}
                            {/*        <tr>*/}
                            {/*            <td><h6>{property_name}</h6></td>*/}
                            {/*            <td style={{textAlign: "center", fontWeight: "bold"}}>{no_of_rooms}</td>*/}
                            {/*            <td style={{textAlign: "center"}}>Rs.{price / no_of_rooms}</td>*/}
                            {/*            <td>Rs.{price}</td>*/}
                            {/*        </tr>*/}
                            {/*        <tr>*/}
                            {/*            <td colSpan={"2"}><h6>Taxes(in GST 18%):-</h6></td>*/}
                            {/*            <td style={{textAlign: "center"}}>Rs.{gst}</td>*/}
                            {/*            <td>Rs.{gst}</td>*/}
                            {/*        </tr>*/}
                            {/*        <tr>*/}
                            {/*            <td colSpan="2" className="text-end fw-bold">Grand total</td>*/}
                            {/*            <td colSpan="2" className="text-end fw-bold">Rs.{grandTotal}</td>*/}
                            {/*        </tr>*/}
                            {/*        </tbody>*/}
                            {/*    </table>*/}
                            {/*</div>*/}
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
