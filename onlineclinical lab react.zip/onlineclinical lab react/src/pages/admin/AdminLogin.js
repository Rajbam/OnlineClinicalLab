import {useForm} from "react-hook-form";
import {useNavigate} from "react-router-dom";
import {ErrorMessage} from "@hookform/error-message";
import axios from "axios";
import Swal from "sweetalert2";
import {useEffect} from "react";

export default function AdminLogin() {
    let navigate = useNavigate();
    let {register, handleSubmit, formState: {errors}, reset} = useForm();


    useEffect(() => {
        axios.get("http://localhost:4000/check-admin-session").then((response) => {
            if (response.data === "success") {
                navigate("/admin/admin-change-password");
            }
        }).catch((error) => {
            console.log(error);
        })
    }, []);

    function onSubmit(data) {
        axios.post("http://localhost:4000/check-details", data).then((response) => {
            if (response.data === "failure") {
                Swal.fire('Incorrect Details', 'Invalid username or password!!', 'error');
            }
            else if (response.data === "error") {
                Swal.fire('Technical error', 'Please try again after sometime!!', 'error');
            }
            else if (response.data === "inactive") {
                Swal.fire('Account Blocked', 'Please try again after sometime!!', 'error');
            }
            else {
                console.log(response.data)
                navigate('/admin')
            }
        })
    }



    return (
        <>
           <div className={"d-flex align-content-center"} style={{backgroundImage:`url(${require('../../images/about.jpg')})`,backgroundRepeat:"no-repeat",backgroundSize:"cover", height:'100vh',width:'100%'  }}>
            <div className="d-flex justify-content-center col-md-8 offset-md-2 " >
                <div className="mt-5 ">

                            <div className="form-container " style={{marginTop:"12%"}}>
                                <div className="left-content">
                                    <h3 className="title">Admin Panel</h3>
                                    <h4 className="sub-title">Fusion Clinical Lab</h4>
                                </div>
                                <div className="right-content">
                                    <h3 className="form-title">Login</h3>
                                    <form className="form-horizontal" onSubmit={handleSubmit(onSubmit)}>
                                        <div className="form-group">
                                            <label>Username / Email</label>
                                            <input {...register('name_email', {required: "This field is required"})} type="text"
                                                   className="form-control" style={{border:"1px solid pink"}}/>

                                        </div>
                                        <ErrorMessage name="name_email" errors={errors}
                                                      render={({message}) => <p className="text-danger">{message}</p>}/>
                                        <div className="form-group">
                                            <label>Password</label>
                                            <input {...register('login_pass', {required: "You must enter the password!"})}
                                                   type="password" className="form-control"
                                                   style={{border:"1px solid pink"}} />
                                        </div>
                                        <ErrorMessage name={"login_pass"} errors={errors}
                                                      render={({message}) => <p className={"text-danger"}>{message}</p>}/>

                                        <button className="btn signin">Login</button>
                                    </form>
                                </div>
                            </div>


                </div>
            </div>
           </div>
        </>
    )
}