import {NavLink, Outlet} from "react-router-dom"
import Banner from "../../component/banner";
import axios from "axios";
import {useContext} from "react";
import {AdminContext} from "./ProtectedAdminRoute";

export default function AdminLayout() {
    const session_admin=useContext(AdminContext);
    function logOutAdmin() {
        axios.post("http://localhost:4000/logout").then((response) => {
            console.log(response.data);
        }).catch((error) => {
            console.log(error);
        })
    }

    return (
        <>
            <header id="site-header" className="fixed-top">
                <div className="">
                    <nav className="navbar navbar-expand-lg navbar-light">
                        <NavLink className="navbar-brand" to="#">
                            <i className="fas fa-tooth"></i>Dentition
                        </NavLink>
                        <button className="navbar-toggler collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false"
                                aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon fa icon-expand fa-bars"></span>
                            <span className="navbar-toggler-icon fa icon-close fa-times"></span>
                        </button>
                        <div className="collapse navbar-collapse" id="navbarScroll">
                            <ul className="navbar-nav ms-auto me-2 my-2 my-lg-0 navbar-nav-scroll">
                                <li className="nav-item">
                                    <NavLink className="nav-link active" aria-current="page" to="/admin">Home</NavLink>
                                </li>
                                {
                                    session_admin.type === 'admin' ? <li className="dropdown ">
                                        <button type="button" className="btn-transparent cursor-pointer dropdown-toggle"
                                                data-bs-toggle="dropdown">Manage Co-admin
                                        </button>
                                        <ul className="dropdown-menu">
                                            <NavLink className="bg-custom" to="/admin/add-admin">Add Co-admin</NavLink>
                                            <NavLink className="bg-custom" to="/admin/view-admin">View Co-admin</NavLink>
                                        </ul>
                                    </li> :""
                                }
                                <li className="nav-item">
                                    <NavLink className="nav-link"
                                             to="/admin/admin-change-password">ChangePassword</NavLink>
                                </li>
                                <li className="nav-item">
                                    <NavLink className="nav-link" to="/admin/admin-login" role={"button"}
                                             onClick={logOutAdmin}>LogOut</NavLink>
                                </li>
                            </ul>
                            {/*<form action="#error" method="GET" className="d-flex search-header">*/}
                            {/*    <input className="form-control" type="search" placeholder="Enter Keyword..."*/}
                            {/*           aria-label="Search"*/}
                            {/*           required/>*/}
                            {/*        <button className="btn btn-style" type="submit"><i className="fas fa-search"></i>*/}
                            {/*        </button>*/}
                            {/*</form>*/}
                        </div>

                        <div className="cont-ser-position">
                            <nav className="navigation">
                                <div className="theme-switch-wrapper">
                                    <label className="theme-switch" htmlFor="checkbox">
                                        <input type="checkbox" id="checkbox"/>
                                        <div className="mode-container">
                                            <i className="gg-sun"></i>
                                            <i className="gg-moon"></i>
                                        </div>
                                    </label>
                                </div>
                            </nav>
                        </div>

                    </nav>
                </div>
            </header>


            {/*<section className="w3l-main-slider" id="home">*/}
            {/*    <div className="banner-content">*/}
            {/*        <div id="demo-1">*/}
            {/*            <div className="demo-inner-content">*/}
            {/*                <div className="container">*/}
            {/*                    <div className="banner-info">*/}
            {/*                        <p className="mb-1">Only one kind of Treatement!</p>*/}
            {/*                        <h3>Your New Smile</h3>*/}
            {/*                        <NavLink className="btn btn-style btn-style-2 mt-sm-5 mt-4" to="appointment.html">Book*/}
            {/*                            Now</NavLink>*/}
            {/*                    </div>*/}
            {/*                </div>*/}
            {/*            </div>*/}
            {/*        </div>*/}
            {/*    </div>*/}
            {/*</section>*/}
            <br/>
            <br/>
            <br/>
            <br/>


            <Outlet/>


            <footer className="w3l-footer-29-main">
                <div className="footer-29 pt-5 pb-4">
                    <div className="container pt-md-4">
                        <div className="row footer-top-29">
                            <div className="col-md-5 footer-list-29 pe-xl-5">
                                <h6 className="footer-title-29">Contact Info </h6>
                                <p className="mb-2 pe-xl-5">Address : Dentition, 10001, 5th Avenue, #06 lane street, NY
                                    - 62617.
                                </p>
                                <p className="mb-2">Phone Number : <NavLink to="tel:+1(21) 234 4567">+1(21) 234
                                    4567</NavLink></p>
                                <p className="mb-2">Email : <NavLink
                                    to="mailto:info@example.com">info@example.com</NavLink></p>
                            </div>
                            <div className="col-md-2 col-4 footer-list-29 mt-md-0 mt-4">
                                <ul>
                                    <h6 className="footer-title-29">About</h6>
                                    <li><NavLink to="services.html">Services</NavLink></li>
                                    <li><NavLink to="about.html">Special Offers</NavLink></li>
                                    <li><NavLink to="about.html">Orthodontics</NavLink></li>
                                    <li><NavLink to="about.html">About Us</NavLink></li>
                                </ul>
                            </div>
                            <div className="col-lg-3 col-md-3 col-4 ps-lg-5 ps-md-4 footer-list-29 mt-md-0 mt-4">
                                <ul>
                                    <h6 className="footer-title-29">Explore</h6>
                                    <li><a href="#blog">Blog Posts</a></li>
                                    <li><a href="#privacy">Privacy policy</a></li>
                                    <li><a href="contact.html">Contact Us</a></li>
                                    <li><a href="#license">License & uses</a></li>
                                </ul>
                            </div>
                            <div className="col-lg-2 col-md-2 col-4 footer-list-29 mt-md-0 mt-4">
                                <ul>
                                    <h6 className="footer-title-29">Dentition</h6>
                                    <li><NavLink to="#doctor">Dr. John Doe</NavLink></li>
                                    <li><NavLink to="#doctor">Dr. Martin Ker</NavLink></li>
                                    <li><NavLink to="#doctor">Dr. Alexander</NavLink></li>
                                    <li><NavLink to="#doctor">Dr. Eliz Wilson</NavLink></li>
                                </ul>
                            </div>
                        </div>

                        <p className="copy-footer-29 text-center pt-lg-2 mt-5 pb-2">© 2022 Dentition. All rights
                            reserved. Design by
                            <b>Paras Puri</b></p>

                    </div>
                </div>
            </footer>


        </>
    )
}