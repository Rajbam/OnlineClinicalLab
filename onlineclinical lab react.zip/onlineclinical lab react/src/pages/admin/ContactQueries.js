import Banner from "../../component/banner";
import ReactLoading from "react-loading";
import axios from "axios";
import {useEffect, useState} from "react";
import Swal from "sweetalert2";


export default function ContactQueries() {
    let [data, setData] = useState([]);
    let [stat, setStat] = useState(false);

    function getdata() {
        axios.get("http://localhost:4000/getcontactqueries").then((response) => {
            setTimeout(() => {
                if (response.data !== "nodata") {
                    setData(response.data);
                    setStat(true);
                } else if (response.data === "nodata") {
                    setData([]);
                    setStat(true);
                }
            }, 3000)
        }).catch((error) => {
            console.log(error);
        })
    }

    useEffect(() => {
        getdata();
    }, []);

    function StatusChange(id) {
        let data = {id};
        axios.post("http://localhost:4000/statuschange", data).then((response) => {
                if (response.data === "success") {
                    getdata();
                } else {
                    Swal.fire("Tecnical Error", "Contact your Developer", "error");
                }

            }
        )
    }


    return (
        <>
            <Banner name={" Contact Queries"} Previous={"Admin Home"}/>
            {
                stat ?
                    data.length === 0 ?
                        <div className={"custom-flex container bg-inactive"}><h1
                            className={"custom-flex pt-5 font height-view"}>No User Queries
                            Found!!</h1>
                        </div> :
                        <section className="ftco-section">
                            <div className="container">
                                <div className="row justify-content-center">
                                    <div className="col-md-6 text-center mb-5">
                                        <h2 className="style-font">Pending User Queries</h2>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-12">
                                        <div className="table-wrap">
                                            <table className="table table-responsive-xl">
                                                <thead>
                                                <tr>
                                                    <th>Id</th>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Subject</th>
                                                    <th>Phone</th>
                                                    <th>Message</th>
                                                    <th>Action</th>

                                                </tr>
                                                </thead>
                                                <tbody>
                                                {
                                                    data.map((value, index) => {
                                                        let {
                                                            email,
                                                            id,
                                                            name,
                                                            message,
                                                            phone,
                                                            status,
                                                            subject

                                                        } = value;
                                                        return (
                                                            <tr key={index}>
                                                                <td>{id}</td>
                                                                <td>{name}</td>
                                                                <td>{email}</td>
                                                                <td>{subject}</td>
                                                                <td>{phone}</td>


                                                                <td>{message}</td>

                                                                <td>
                                                                    <button onClick={() => StatusChange(id)}
                                                                            className={"btn btn-primary"}>Solved?
                                                                    </button>
                                                                </td>


                                                            </tr>
                                                        )
                                                    })
                                                }
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section> :
                    <>
                        <div className={"custom-flex"}><h1 className={"font"}>Fetching Requests</h1><ReactLoading
                            className={"d-flex justify-content-center"}
                            type={"balls"} color={"darkred"} height={800} width={90}/>
                        </div>
                    </>
            }
        </>
    )

}