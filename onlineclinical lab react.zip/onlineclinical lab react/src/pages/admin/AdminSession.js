import {useContext} from "react";
import {useNavigate} from "react-router-dom";
import {AdminContext} from "./ProtectedAdminRoute";

export function AdminSession({Component}){
    const session_admin=useContext(AdminContext);
    let navigate = useNavigate();
    if (session_admin.type === 'co-admin'){
        navigate('/admin');
    }
    return(
        <>
            <Component/>
        </>
    )
}