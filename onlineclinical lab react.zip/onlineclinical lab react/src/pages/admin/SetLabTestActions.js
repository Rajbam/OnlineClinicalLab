
import ReactLoading from "react-loading";
import {useEffect, useState} from "react";
import axios from "axios";
import Swal from "sweetalert2";
import Banner from "../../component/banner";

export default function SetLabTestActions() {
    let [data, setData] = useState([]);
    let [stat, setStat] = useState(false);

    function getData() {
        setStat(false);
        let status = {activatestatus: "activated"};
        axios.post("http://localhost:4000/getlabpendingtest", status).then((response) => {
            setTimeout(() => {
                if (response.data !== "nodata") {
                    setData(response.data);
                    setStat(true);
                } else if (response.data === "nodata") {
                    setData([]);
                    setStat(true);
                }
            }, 3000)
        }).catch((error) => {
            console.log(error);
        })
    }

    useEffect(() => {
        getData();
    }, []);

    function activateAccount(lt_id) {
        let status = {lt_id: lt_id , accountstatus: "pending"};
        axios.post("http://localhost:4000/lab-test-actions", status).then((response) => {
            if (response.data === "activated") {
                Swal.fire({icon: "success", title: "Lab test has been Unblocked"});
                getData();
            } else if (response.data === "error") {
                Swal.fire({icon: "error", title: "Error occured at backend"});
                getData();
            }
        }).catch((error) => {
            console.log(error);
        })
    }

    function deactivateAccount(lt_id) {
        let status = {lt_id:lt_id, accountstatus: "activated"};
        axios.post("http://localhost:4000/lab-test-actions", status).then((response) => {
            if (response.data === "blocked") {
                Swal.fire({icon: "success", title: "Owner's property has been blocked"});
                getData();
            } else if (response.data === "error") {
                Swal.fire({icon: "error", title: "Error occured at backend"});
                getData();
            }
        }).catch((error) => {
            console.log(error);
        })
    }

    return (
        <>
            <Banner name={" Owner Actions"} Previous={"Admin Home"}/>
            {
                stat ?
                    data.length === 0 ?
                        <div className={"custom-flex container bg-inactive"}><h1
                            className={"custom-flex pt-5 font height-view"}>No Data
                            Found!!</h1>
                        </div> :
                        <section className="ftco-section">
                            <div className="container">
                                <div className="row justify-content-center">
                                    <div className="col-md-6 text-center mb-5">
                                        <h2 className="style-font">LAB TEST DETAILS</h2>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-12">
                                        <div className="table-wrap">
                                            <table className="table table-responsive-xl">
                                                <thead>
                                                <tr>
                                                    <th>Lab id</th>
                                                    <th>Test name</th>
                                                    <th>Description</th>
                                                    <th>Category</th>
                                                    <th>Price</th>
                                                    <th>Status</th>
                                                    <th colSpan={"2"} className={"text-center"}>Actions</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                {
                                                    data.map((value, index) => {
                                                        let {
                                                            category,
                                                            description,
                                                            lab,
                                                            lt_id,
                                                            price,
                                                            status,
                                                            test_name
                                                        } = value;
                                                        return (
                                                            <tr key={index}>
                                                                <td>{lt_id}</td>
                                                                <td>{test_name}</td>
                                                                <td>{description}</td>
                                                                <td>{category}</td>


                                                                <td>{price}</td>
                                                                {
                                                                    status === "activated" ?
                                                                        <td className={"status"}><span
                                                                            className="active">{status}</span>
                                                                        </td> : <td className={"status"}><span
                                                                            className="inactive">{status}</span>
                                                                        </td>
                                                                }
                                                                <td className='text-center'>
                                                                    {
                                                                        status === "activated" ? <button
                                                                            onClick={() => deactivateAccount(lt_id)}
                                                                            type={"button"}
                                                                            className={"btn btn-danger "}>Block
                                                                        </button> : <button
                                                                            onClick={() => activateAccount(lt_id)}
                                                                            type={"button"}
                                                                            className={"btn btn-success"} >Unblock
                                                                        </button>
                                                                    }
                                                                </td>
                                                            </tr>
                                                        )
                                                    })
                                                }
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section> :
                    <>
                        <div className={"custom-flex"}><h1 className={"font"}>Fetching Data</h1><ReactLoading
                            className={"d-flex justify-content-center"}
                            type={"balls"} color={"darkred"} height={800} width={90}/>
                        </div>
                    </>
            }
        </>
    )
}