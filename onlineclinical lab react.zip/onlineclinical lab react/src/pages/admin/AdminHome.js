import Banner from "../../component/banner";
import {NavLink} from "react-router-dom";

export  default  function AdminHome(){
    return(
        <>
            <Banner name={"Admin Home"} Previous={""}/>

            <h1 align="center">Admin Dashboard</h1>

                <div className="container">
                    <div className="row">
                        <div className="col-sm-4">
                            <div className="card mb-3" style={{width: '100%', height: '200px',backgroundColor: '#d2525e'}}>
                                <div className="card-body">
                                    <h3 className="text-center">View Pending Lab Owners</h3>
                                </div>
                                    <NavLink to={"/admin/view-pending-owner"} className="card-footer text-center text-decoration-none" style={{backgroundColor: 'black'}}><p>View Pending Lab Owners <i className="fa fa-arrow-right me-3"></i></p></NavLink>

                            </div>
                        </div>
                        <div className="col-sm-4">
                            <div className="card mb-3" style={{width: '100%', height: '200px',backgroundColor: 'violet'}}>
                                <div className="card-body">
                                    <h3 className="text-center">Set Lab Owner Actions</h3>
                                </div>
                                    <NavLink to={"/admin/actions-owner"} className="card-footer text-center text-decoration-none" style={{backgroundColor: 'black'}}><p>Set Lab Owner Actions  <i className="fa fa-arrow-right me-3"></i></p> </NavLink>

                            </div>
                        </div>
                        <div className="col-sm-4">
                            <div className="card mb-3" style={{width: '100%', height: '200px',backgroundColor: 'springgreen'}}>
                                <div className="card-body">
                                    <h3 className="text-center">View Pending Lab Test</h3>
                                </div>
                                    <NavLink to={"/admin/view-pending-lab-test"} className="card-footer text-center text-decoration-none" style={{backgroundColor: 'black'}}><p>View Pending Lab Test <i className="fa fa-arrow-right me-3"></i></p> </NavLink>

                            </div>
                        </div>
                        <div className="col-sm-4">
                            <div className="card mb-3" style={{width: '100%', height: '200px',backgroundColor: '#dee2e6'}}>
                                <div className="card-body">
                                    <h3 className="text-center">Set Lab Test Actions</h3>

                                </div>
                                    <NavLink to={"/admin/view-lab-test-actions"} className="card-footer text-center text-decoration-none" style={{backgroundColor: 'black'}}><p>Set Lab Test Actions<i className="fa fa-arrow-right me-3"></i> </p></NavLink>

                            </div>
                        </div>
                        <div className="col-sm-4">
                            <div className="card mb-3" style={{width: '100%', height: '200px',backgroundColor: '#6f42c1'}}>
                                <div className="card-body">
                                    <h3 className="text-center">User Queries</h3>
                                </div>
                                    <NavLink to={"/admin/user-queries"} className="card-footer text-center text-decoration-none" style={{backgroundColor: 'black'}}><p >User Queries<i className="fa fa-arrow-right me-3"></i></p></NavLink>

                            </div>
                        </div>
                        <div className="col-sm-4">
                            <div className="card mb-3" style={{width: '100%', height: '200px',backgroundColor: '#7abaff'}}>
                                <div className="card-body">
                                    <h3 className={"text-center"}>View User Bookings</h3>
                                </div>
                                    <NavLink to={"/admin/view-bookings"} className="card-footer text-center text-decoration-none" style={{backgroundColor: 'black'}}><p><i className="fa fa-arrow-right me-3">View Bookings</i> </p>
                                     </NavLink>

                            </div>
                        </div>
                    </div>
                </div>

        </>
    )
}